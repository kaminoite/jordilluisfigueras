/*
 * complexmp.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef __COMPLEXMP_H
#define __COMPLEXMP_H

#define COMPLEXMP_VERSION 2.0.0

#include<gmp.h>
#include<mpfr.h>
#include<iostream>
#include"realmp.h"

namespace torkam
{

class complex
{
public:

  real re;
  real im;

  complex();
  complex(const complex& y);
  complex(const real& r, const real& i);
  ~complex();

  complex& operator = (const complex& y);
  complex& operator = (const real& y);
};

complex operator - (const complex& x);
complex conj(const complex& x);
complex operator + (const complex& x, const complex& y);
complex operator + (const complex& x, const real& y);
complex operator + (const real& x, const complex& y);
complex operator - (const complex& x, const complex& y);
complex operator - (const complex& x, const real& y);
complex operator - (const real& x, const complex& y);
complex operator * (const complex& x, const complex& y);
complex operator * (const complex& x, const real& y);
complex operator * (const real& x, const complex& y);
complex operator / (const complex& x, const complex& y);
complex operator / (const real& x, const complex& y);
complex operator / (const complex& x, const real& r);
complex sqr(const complex& x);
complex cos(const complex& x);
complex sin(const complex& x);
complex sqrt(const complex& x);
complex pow(const complex& x, int n);
complex pow(const complex& x, const real& a);
real abs(const complex& x);
//std::ostream& operator<<(std::ostream& os, const complex& obj);
complex eval_pol(complex* coef, const real& x, int N);
complex eval_pol(complex* coef, const complex& x, int N);

}
#endif
