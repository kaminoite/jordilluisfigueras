/*
 * realmpI.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef __REALMPI_H
#define __REALMPI_H

#define REALMPI_VERSION 1.0

#include<mpfi.h>
#include<mpfi_io.h>
#include"realmp.h"

namespace torkam
{

class realI
{
public:
	mpfi_t x;

  realI();
	realI(double a);
	realI(const real& a);
  realI(int a);
	realI(double a, double b);
	realI(const char *a);
	~realI();

	void setfull(double a, double b);
	void setfull(mpfr_t a, mpfr_t b);
	int position(double a);
	int position(mpfr_t a)const;
	int is_inside(double a);

	double left();
	double right();

	real left_real();
	real right_real();

	realI& operator = (const realI& y);
	realI& operator = (const double& y);
	realI& operator = (const mpfr_t& y);
	realI& operator = (const real& y);
  realI& operator += (const realI& P);
  realI& operator -= (const realI& P);
};

realI operator- (const realI& P);

realI operator+ (const realI&, const realI&);
realI operator+ (const double&, const realI&);
realI operator+ (const realI&, const double&);
realI operator+ (const mpfr_t&, const realI&);
realI operator+ (const realI&, const mpfr_t&);

realI operator- (const realI&, const realI&);
realI operator- (const double&, const realI&);
realI operator- (const realI&, const double&);
realI operator- (const mpfr_t&, const realI&);
realI operator- (const realI&, const mpfr_t&);
realI operator- (const real&, const realI&);
realI operator- (const realI&, const real&);

realI operator* (const realI&, const realI&);
realI operator* (const double&, const realI&);
realI operator* (const realI&, const double&);
realI operator* (const int&, const realI&);
realI operator* (const realI&, const int&);
realI operator* (const realI& P, const real& Q);
realI operator* (const real& Q, const realI& P);

realI operator/ (const realI&, const realI&);
realI operator/ (const double&, const realI&);
realI operator/ (const realI&, const double&);
realI operator/ (const realI&, const real&);

int is_inside(const realI& a, const realI& b);

void realmpI_allocate_cache(int prec);
realI midpointI(const realI& I);
realI const_piI(void);
realI abs(const realI& P);
realI sin(const realI& P);
realI sinh(const realI& P);
realI cos(const realI& P);
realI cosh(const realI& P);
realI exp(const realI& P);
realI log(const realI& P);
realI sqrt(const realI& P);
realI sqr(const realI& P);
realI atan2(const realI& P, const realI& Q);
realI pow(const realI& P, int N);

realI str_to_realI(char *s);

bool check_invertibility(realI **A, int dim);

realI eval_pol(realI* coef, const realI& x, int N);

realI unionI(const realI& a, const realI& b);

extern realI val0I, val1I, val2I, val3I, val4I, val5I, val6I, val7I, val8I, val9I, val10I;
extern realI piI, pi2I, pihalfI;
/*-------------------------------------------------------------------------------------------------------------------------------------------*/

}
#endif
