/*
 * complexmp.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "complexmp.h"

namespace torkam
{

complex::complex ()
{
  re = real(0);
  im = real(0);
}

complex::complex (const complex& y)
{
  re = y.re;
  im = y.im;
}

complex::complex(const real& r, const real& i)
{
  re = r;
  im = i;
}

complex::~complex()
{
}

complex& complex::operator = (const complex& y) 
{ 
  re = y.re; 
  im = y.im; 
  return *this; 
} 

complex& complex::operator = (const real& y) 
{ 
  re = y; 
  im = real(0); 
  return *this; 
} 

//  functions

complex operator - (const complex& x)
{
  return complex(-x.re, -x.im);
}

complex conj(const complex& x)
{
  return complex(x.re, -x.im);
}

complex operator + (const complex& x, const complex& y)
{
  return complex(x.re + y.re, x.im + y.im);
}

complex operator + (const complex& x, const real& y)
{
  return complex(x.re + y, x.im);
}

complex operator + (const real& x, const complex& y)
{
  return complex(x + y.re, y.im);
}

complex operator - (const complex& x, const complex& y)
{
  return complex(x.re - y.re, x.im - y.im);
}

complex operator - (const complex& x, const real& y)
{
  return complex(x.re - y, x.im);
}

complex operator - (const real& x, const complex& y)
{
  return complex(x - y.re, -y.im);
}

complex operator * (const complex& x, const complex& y)
{
  return complex(x.re * y.re - x.im * y.im, x.re * y.im + x.im * y.re);
}

complex operator * (const complex& x, const real& y)
{
  return complex(x.re*y, x.im*y);
}

complex operator * (const real& x, const complex& y)
{
  return complex(x*y.re, x*y.im);
}

complex operator / (const complex& x, const complex& y)
{
  real d;
  d = y.re*y.re+y.im*y.im;
  return complex((x.re*y.re+x.im*y.im)/d, (x.im*y.re-x.re*y.im)/d);
}

complex operator / (const real& x, const complex& y)
{
  real d;
  d = y.re*y.re+y.im*y.im;
  return complex((x*y.re)/d,(-x*y.im)/d);
}

complex operator / (const complex& x, const real& r)
{
  return complex(x.re/r,x.im/r);
}

complex sqr(const complex& x)
{
  return x*x;
}

complex cos(const complex& x)
{
  return complex(cos(x.re)*cosh(x.im),-sin(x.re)*sinh(x.im));
}

complex sin(const complex& x)
{
  return complex(sin(x.re)*cosh(x.im),cos(x.re)*sinh(x.im));
}

real abs(const complex& x)
{
  return sqrt(x.re*x.re+x.im*x.im);
}

complex pow(const complex& x, int n)
{
  real r;
  real te;
  r = sqrt(x.re*x.re+x.im*x.im);
  te = atan2(x.im, x.re);
  return complex(pow(r,n)*cos(te*real(n)),pow(r,n)*sin(te*real(n)));
}

complex pow(const complex& x, const real& a)
{
  real r; 
  real te;
  r = sqrt(x.re*x.re+x.im*x.im);
  te = atan2(x.im, x.re);
  return complex(pow(r,a)*cos(te*a),pow(r,a)*sin(te*a));
}

complex sqrt(const complex& x)
{
  real r;
  real te;
  r = sqrt(x.re*x.re+x.im*x.im);
  te = atan2(x.im, x.re);
  return complex(sqrt(r)*cos(te/real(2)),sqrt(r)*sin(te/real(2)));
}

/* NOT SUPPORTED 
 *
 * std::ostream& operator<<(std::ostream& os, const complex& obj)
{
  if(obj.im < val0) 
    cout << obj.re << "-I*" << -obj.im;
  else 
    cout << obj.re << "+I*" << obj.im;

  return os;
}
*/

/*  DOC complex eval_pol(real* coef, const complex& x, int N)
 *  DOC 
 *  DOC Input: array N with coef[0], ... coef[N-1]; x complex, N degree-1
 *  DOC Output: coef[0]+x*coef[1]+x^2*coef[2]+...+x^(N-1)*coef[N-1]
 *  DOC 
 */
complex eval_pol(real* coef, const complex& x, int N)
{
  complex res;

  res = coef[N-1];

  for(int i = N-2; i > -1; i--)
  {
    res = res*x+coef[i];
  }

  return res;
}

/*  DOC complex eval_pol(complex* coef, const complex& x, int N)
 *  DOC 
 *  DOC Input: array N with coef[0], ... coef[N-1]; x complex, N degree-1
 *  DOC Output: coef[0]+x*coef[1]+x^2*coef[2]+...+x^(N-1)*coef[N-1]
 *  DOC 
 */
complex eval_pol(complex* coef, const complex& x, int N)
{
  complex res;

  res = coef[N-1];

  for(int i = N-2; i > -1; i--)
  {
    res = res*x+coef[i];
  }

  return res;
}

}
