/*
 * realmp.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Joan Gimeno, and Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "realmp.h"

namespace torkam
{

real val0, val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
real pi, pi2, pihalf;

real::real(void)
{
  mpfr_init(x);
//  mpfr_set_d(x, (double)0., GMP_RNDN);
}

real::real(int a)
{
  mpfr_init(x);
  mpfr_set_si(x, a, GMP_RNDN);
}

real::real(unsigned int a)
{
  mpfr_init(x);
  mpfr_set_ui(x, a, GMP_RNDN);
}

real::real(long a)
{
  mpfr_init(x);
  mpfr_set_si(x, a, GMP_RNDN);
}

real::real(unsigned long a)
{
  mpfr_init(x);
  mpfr_set_ui(x, a, GMP_RNDN);
}


real::real(double a)
{
  mpfr_init(x);
  mpfr_set_d(x, a, GMP_RNDN);
}

real::real(const char *a)
{
  mpfr_init(x);
  mpfr_set_str(x, a, 10, GMP_RNDN);
}

real::~real(void)
{
  mpfr_clear(x);
}

real& real::operator += (const real& P)
{
  if(this != &P) // I think this is not needed
  {
      mpfr_add(x, x, P.x, GMP_RNDN);
  }
  return *this;
}

real& real::operator *= (const real& P)
{
  if(this != &P)
  {
      mpfr_mul(x, x, P.x, GMP_RNDN);
  }
  return *this;
}

real& real::operator /= (const real& P)
{
  if(this != &P)
  {
      mpfr_div(x, x, P.x, GMP_RNDN);
  }
  return *this;
}


real& real::operator = (const real& P)
{
  if(this != &P)
  {
      mpfr_set(x, P.x, GMP_RNDN);
  }
  return *this;
}

real& real::operator = (const double& P)
{
  mpfr_set_d(x, P, GMP_RNDN);

  return *this;
}

real& real::operator = (const int& P)
{
  mpfr_set_si(x, P, GMP_RNDN);

  return *this;
}

real real::operator- (void) const
{
  real res;

  mpfr_neg(res.x, this->x, GMP_RNDN);

  return res;
}

real real::operator+ (const real& Q) const
{
  real res;

  mpfr_add(res.x, this->x, Q.x, GMP_RNDN);

  return res;
}
//real real::operator+ (const real& Q) {return real::operator +(Q);}

real real::operator+ (const double& Q) const
{
  real res;

  mpfr_add_d(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real operator+ (const double& P, const real& Q)
{
  real res;

  mpfr_add_d(res.x, Q.x, P, GMP_RNDN);

  return res;
}

real real::operator- (const real& Q) const
{
  real res;

  mpfr_sub(res.x, this->x, Q.x, GMP_RNDN);

  return res;
}

real real::operator- (const double& Q) const
{
  real res;

  mpfr_sub_d(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real operator- (const double& P, const real& Q)
{
  real res;

  mpfr_d_sub(res.x, P, Q.x, GMP_RNDN);

  return res;
}

real real::operator* (const real& Q) const
{
  real res;

  mpfr_mul(res.x, this->x, Q.x, GMP_RNDN);

  return res;
}

real real::operator* (const double& Q) const
{
  real res;

  mpfr_mul_d(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real real::operator* (const int& Q) const
{
  real res;

  mpfr_mul_d(res.x, this->x, (double)Q, GMP_RNDN);

  return res;
}

real operator* (const double& P, const real& Q)
{
  real res;

  mpfr_mul_d(res.x, Q.x, P, GMP_RNDN);

  return res;
}

real operator* (const int& P, const real& Q)
{
  real res;

  mpfr_mul_d(res.x, Q.x, (double)P, GMP_RNDN);

  return res;
}

real operator* (const real& Q, const int& P)
{
  real res;

  mpfr_mul_d(res.x, Q.x, (double)P, GMP_RNDN);

  return res;
}

real real::operator/ (const real& Q) const
{
  real res;

  mpfr_div(res.x, this->x, Q.x, GMP_RNDN);

  return res;
}

real real::operator/ (const double& Q) const
{
  real res;

  mpfr_div_d(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real real::operator/ (const int& Q) const
{
  real res;

  mpfr_div_si(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real real::operator/ (const long int& Q) const
{
  real res;

  mpfr_div_si(res.x, this->x, Q, GMP_RNDN);

  return res;
}

real operator/ (const double& P, const real& Q)
{
  real res;

  mpfr_d_div(res.x, P, Q.x, GMP_RNDN);

  return res;
}

int real::operator> (const real& Q) const
{
  int res;

  res = mpfr_cmp(this->x, Q.x);

  if(res > 0) res = 1;
  else res = 0;

  return res;
}

int real::operator> (double Q) const
{
  int res;

  res = mpfr_cmp_d(this->x, Q);

  if(res > 0) res = 1;
  else res = 0;

  return res;
}

int operator> (double P, const real& Q)
{
  int res;

  res = mpfr_cmp_d(Q.x, P);

  if(res < 0) res = 1;
  else res = 0;

  return res;
}

int real::operator< (const real& Q) const
{
  int res;

  res = mpfr_cmp(this->x, Q.x);

  if(res < 0) res = 1;
  else res = 0;

  return res;
}

int real::operator< (double Q) const
{
  int res;

  res = mpfr_cmp_d(this->x, Q);

  if(res < 0) res = 1;
  else res = 0;

  return res;
}

int operator< (double P, const real& Q)
{
  int res;

  res = mpfr_cmp_d(Q.x, P);

  if(res > 0) res = 1;
  else res = 0;

  return res;
}

int real::operator>= (const real& Q) const
{
  int res;

  res = mpfr_cmp(this->x, Q.x);

  if(res >= 0) res = 1;
  else res = 0;

  return res;
}

int real::operator>= (double Q) const
{
  int res;

  res = mpfr_cmp_d(this->x, Q);

  if(res >= 0) res = 1;
  else res = 0;

  return res;
}

int operator>= (double P, const real& Q)
{
  int res;

  res = mpfr_cmp_d(Q.x, P);

  if(res <= 0) res = 1;
  else res = 0;

  return res;
}

int real::operator<= (const real& Q) const
{
  int res;

  res = mpfr_cmp(this->x, Q.x);

  if(res <= 0) res = 1;
  else res = 0;

  return res;
}

int real::operator<= (double Q) const
{
  int res;

  res = mpfr_cmp_d(this->x, Q);

  if(res <= 0) res = 1;
  else res = 0;

  return res;
}

int operator<= (double P, const real& Q)
{
  int res;

  res = mpfr_cmp_d(Q.x, P);

  if(res >= 0) res = 1;
  else res = 0;

  return res;
}

/*  DOC int prec_digits_to_bits(int digits)
 *  DOC 
 *  DOC Input: int digits
 *  DOC Output: an upper bound of the precision realmp needs for assuring accuracy 10^{-digits}
 *  DOC 
 */
int prec_digits_to_bits(int digits)
{
  return int(digits*3.322)+5; 
}

void realmp_allocate_cache(int prec)
{
  mpfr_set_default_prec(prec);

  mpfr_set_prec(val0.x, prec); val0 = real("0.0");
  mpfr_set_prec(val1.x, prec); val1 = real("1.0");
  mpfr_set_prec(val2.x, prec); val2 = real("2.0");
  mpfr_set_prec(val3.x, prec); val3 = real("3.0");
  mpfr_set_prec(val4.x, prec); val4 = real("4.0");
  mpfr_set_prec(val5.x, prec); val5 = real("5.0");
  mpfr_set_prec(val6.x, prec); val6 = real("6.0");
  mpfr_set_prec(val7.x, prec); val7 = real("7.0");
  mpfr_set_prec(val8.x, prec); val8 = real("8.0");
  mpfr_set_prec(val9.x, prec); val9 = real("9.0");
  mpfr_set_prec(val10.x, prec); val10 = real("10.0");

  mpfr_set_prec(pi.x, prec); pi = const_pi();
  mpfr_set_prec(pi2.x, prec); pi2 = pi*val2;
  mpfr_set_prec(pihalf.x, prec); pihalf = pi/val2;

}

void realmp_free_cache(void)
{
  mpfr_free_cache();
}

real const_pi(void)
{
  real res;

  mpfr_const_pi(res.x, GMP_RNDN);

  return res;
}

real cos(const real& P)
{
  real res;

  mpfr_cos(res.x, P.x, GMP_RNDN);

  return res;
}

real acos(const real& P)
{
  real res;

  mpfr_acos(res.x, P.x, GMP_RNDN);

  return res;
}

real sin(const real& P)
{
  real res;

  mpfr_sin(res.x, P.x, GMP_RNDN);

  return res;
}

real tan(const real& P)
{
  real res;

  mpfr_tan(res.x, P.x, GMP_RNDN);

  return res;
}

real atan(const real& P)
{
  real res;

  mpfr_atan(res.x, P.x, GMP_RNDN);

  return res;
}

real atan2(const real&Q, const real& P)
{
  real res;

  mpfr_atan2(res.x, Q.x, P.x, GMP_RNDN);

  return res;
}

real cosh(const real& P)
{
  real res;

  mpfr_cosh(res.x, P.x, GMP_RNDN);

  return res;
}

real sinh(const real& P)
{
  real res;

  mpfr_sinh(res.x, P.x, GMP_RNDN);

  return res;
}

real exp(const real& P)
{
  real res;

  mpfr_exp(res.x, P.x, GMP_RNDN);

  return res;
}

real log(const real& P)
{
  real res;

  mpfr_log(res.x, P.x, GMP_RNDN);

  return res;
}

real log10(const real& P)
{
  real res;

  mpfr_log10(res.x, P.x, GMP_RNDN);

  return res;
}

real ceil(const real& P)
{
  real res;

  mpfr_ceil(res.x, P.x);

  return res;
}

real floor(const real& P)
{
  real res;

  mpfr_floor(res.x, P.x);

  return res;
}

real sqr(const real& P)
{
  real res;

  mpfr_sqr(res.x, P.x, GMP_RNDN);

  return res;
}

real cubic(const real& P)
{
  real res;

  res = sqr(P)*P;

  return res;
}

real sqrt(const real& P)
{
  real res;

  mpfr_sqrt(res.x, P.x, GMP_RNDN);

  return res;
}

real abs(const real& P)
{
  real res;

  mpfr_abs(res.x, P.x, GMP_RNDN);

  return res;
}

real pow(const real& P, int N)
{
  real res;

  res = val1;
  if(N > 0)
  {
    for(int i = 0; i < N;i++) res*= P;
  }
  else if (N < 0)
  {
    for(int i = 0; i < -N; i++) res/= P;
  }
  return res;
}

real pow(const real& P, const real& x)
{
  real res;

  mpfr_pow(res.x, P.x, x.x, GMP_RNDN);

  return res;
}

real max(const real& a, const real& b)
{
  real res;

  mpfr_max(res.x, a.x, b.x, GMP_RNDN);

  return res;
}

real max(const real& a, const real& b, const real& c)
{
  real res;

  res = max(a,b);
  if (c > res) res = c;

  return res;
}

real max(const real& a, const real& b,
         const real& c, const real& d)
{
  real res;

  res = max(a,b,c);
  if (d > res) res = d;

  return res;
}

real max(const real& a, const real& b,
         const real& c, const real& d, const real& e)
{
  real res;

  res = max(a,b,c,d);
  if (e > res) res = e;

  return res;
}

/*  DOC real eval_pol(real* coef, const real& x, int N)
 *  DOC 
 *  DOC Input: array N with coef[0], ... coef[N-1]; x real, N degree-1
 *  DOC Output: coef[0]+x*coef[1]+x^2*coef[2]+...+x^(N-1)*coef[N-1]
 *  DOC 
 */
real eval_pol(real* coef, const real& x, int N)
{
  real res;

  res = coef[N-1];

  for(int i = N-2; i > -1; i--)
  {
    res = res*x+coef[i];
  }

  return res;
}

}
