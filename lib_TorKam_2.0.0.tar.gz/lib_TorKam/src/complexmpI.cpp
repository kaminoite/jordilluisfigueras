/*
 * complexmpI.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "complexmpI.h"

//  functions

namespace torkam
{

complexI::complexI ()
{
  re = realI("0");
  im = realI("0");
}

complexI::complexI (const complexI& y)
{
  re = y.re;
  im = y.im;
}

complexI::complexI(const realI& r, const realI& i)
{
  re = r;
  im = i;
}

complexI::complexI(const realI& r, const real& i)
{
  re = r;
  im = i;
}

complexI::complexI(const real& r, const real& i)
{
  re = r;
  im = i;
}

complexI::complexI (const char *a, const char *b) 
{
  mpfi_init_set_str(re.x, a, 10);
  mpfi_init_set_str(im.x, b, 10);
}

complexI::~complexI()
{
}

complexI& complexI::operator = (const complexI& y) 
{ 
  re = y.re; 
  im = y.im; 
  return *this; 
} 

complexI& complexI::operator = (const realI& y) 
{ 
  re = y; 
  im = realI("0"); 
  return *this; 
} 

complexI& complexI::operator = (const real& y) 
{ 
  re = y; 
  im = realI("0"); 
  return *this; 
} 


complexI operator - (const complexI& x)
{
  return complexI(-x.re, -x.im);
}

complexI conj(const complexI& x)
{
  return complexI(x.re, -x.im);
}

complexI operator + (const complexI& x, const complexI& y)
{
  return complexI(x.re + y.re, x.im + y.im);
}

complexI operator + (const complexI& x, const realI& y)
{
  return complexI(x.re + y, x.im);
}

complexI operator + (const realI& x, const complexI& y)
{
  return complexI(x + y.re, y.im);
}

complexI operator - (const complexI& x, const complexI& y)
{
  return complexI(x.re - y.re, x.im - y.im);
}

complexI operator - (const complexI& x, const realI& y)
{
  return complexI(x.re - y, x.im);
}

complexI operator - (const realI& x, const complexI& y)
{
  return complexI(x - y.re, -y.im);
}

complexI operator * (const complexI& x, const complexI& y)
{
  return complexI(x.re * y.re - x.im * y.im, x.re * y.im + x.im * y.re);
}

complexI operator * (const complexI& x, const realI& y)
{
  return complexI(x.re*y, x.im*y);
}

complexI operator * (const realI& x, const complexI& y)
{
  return complexI(x*y.re, x*y.im);
}

complexI operator / (const complexI& x, const complexI& y)
{
  realI d;
  d = y.re*y.re+y.im*y.im;

  return(complexI((x.re*y.re+x.im*y.im)/d, (x.im*y.re-x.re*y.im)/d));
}

complexI operator / (const realI& x, const complexI& y)
{
  realI d;
  d = y.re*y.re+y.im*y.im;
  return(complexI((x*y.re)/d,(-x*y.im)/d));
}

complexI operator / (const complexI& x, const realI& r)
{
  return(complexI(x.re/r,x.im/r));
}

int is_inside(const complexI& a, const complexI& b)
{
  int res;

  res = is_inside(a.re, b.re);
  if(res == 1)
  {
    return 1;
  }
  res = is_inside(a.im, b.im);
  if(res == 1)
  {
    return 1;
  }
  
  return 0;
}

complexI sqr(const complexI& x)
{
  return x*x;
}

complexI cos(const complexI& x)
{
  return(complexI(cos(x.re)*cosh(x.im),-sin(x.re)*sinh(x.im)));
}

complexI sin(const complexI& x)
{
  return(complexI(sin(x.re)*cosh(x.im),cos(x.re)*sinh(x.im)));
}

realI abs(const complexI& x)
{
  return sqrt(sqr(x.re)+sqr(x.im));
}

complexI pow(const complexI& x, int n)
{
  realI r;
  realI te;
  r = sqrt(x.re*x.re+x.im*x.im);
  te = atan2(x.im, x.re);
  return(complexI(pow(r,n)*cos(te*realI(n)),pow(r,n)*sin(te*realI(n))));
}

complexI sqrt(const complexI& x)
{
  realI r;
  realI te;
  r = sqrt(x.re*x.re+x.im*x.im);
  te = atan2(x.im, x.re);
  return(complexI(sqrt(r)*cos(te/realI(2)),sqrt(r)*sin(te/realI(2))));
}

}
