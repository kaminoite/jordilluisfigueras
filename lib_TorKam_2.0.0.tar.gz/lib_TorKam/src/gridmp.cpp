/*
 * gridmp.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "gridmp.h"

namespace torkam
{

real tolcoho;

grid::grid()
{
  ndim=0;
  nelem=0;
  nn=NULL;
  elem=NULL;
}

grid::grid(int dim, int *n)
{
  ndim=dim;
  nelem=1;
  for(int i=0;i<ndim;i++) nelem = nelem*n[i];
  alloc_grid();
  for(int i = 0; i < ndim; i++) nn[i] = n[i];
  for(int i = 0; i < nelem; i++) elem[i] = val0;
}

grid::grid(const grid& y)
{
  ndim=y.ndim;
  nelem=y.nelem;

  alloc_grid();
  for(int i=0;i<ndim;i++) nn[i] = y.nn[i];
  for(int i=0;i<nelem;i++) elem[i] = y.elem[i];
}

grid::~grid()
{
  if(nn!=NULL)
  {
    delete [] nn;
  }
  if(elem!=NULL)
  {
    delete [] elem;
  }
}

inline grid& grid::operator = (const grid& y)
{
  if (this == &y)
  {
    return *this;
  }
  else
  {
    if (ndim!=y.ndim || nelem!=y.nelem)
    {
      this->~grid();
      ndim=y.ndim;
      nelem=y.nelem;
      alloc_grid();
    }
  for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
  for(int i=0;i<nelem;i++) elem[i]=y.elem[i];

  return *this;
  }
}
    
cgrid::cgrid()
{
  ndim=0;
  nelem=0;
  nn=NULL;
  elem=NULL;
}

cgrid::cgrid(int dim, int *n)
{
  ndim=dim;
  nelem=1;
  for(int i=0;i<ndim;i++) nelem = nelem*n[i];
  alloc_cgrid();
  for(int i = 0; i < ndim; i++) nn[i] = n[i];
  for(int i = 0; i < nelem; i++) elem[i] = val0;
}

cgrid::cgrid(const cgrid& y)
{
  ndim=y.ndim;
  nelem=y.nelem;

  alloc_cgrid();
  for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
  for(int i=0;i<nelem;i++) elem[i]=y.elem[i];
}

cgrid::~cgrid()
{
  if(nn!=NULL)
  {
    delete [] nn;
  }
  if(elem!=NULL)
  {
    delete [] elem;
  }
}

inline cgrid& cgrid::operator = (const cgrid& y)
{
  if (this == &y)
  {
    return *this;
  }
  else
  {
    if (ndim!=y.ndim || nelem!=y.nelem)
    {
      this->~cgrid();
      ndim=y.ndim;
      nelem=y.nelem;
      alloc_cgrid();
    }
    for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
    for(int i=0;i<nelem;i++) elem[i]=y.elem[i];

    return *this;
  }
}


// real and imaginary parts of complex grids. Fill version
    
void realpart(const cgrid& g, grid& rg)
{
  for(int i=0; i<g.nelem; i++) rg.elem[i]= g.elem[i].re;
}

void imagpart(const cgrid& g, grid& ig)
{
  for(int i=0; i<g.nelem; i++) ig.elem[i]= g.elem[i].im;
}


void assign_realpart(const grid& rg, cgrid& g)
{
  for(int i=0; i<g.nelem; i++) g.elem[i].re= rg.elem[i];
}


void assign_imagpart(const grid& ig, cgrid& g)
{
  for(int i=0; i<g.nelem; i++) g.elem[i].im= ig.elem[i];
}


// FFTs Backward and Forward
void four1(real *data, int nn, int isign)
/*
  Replaces data[0,...2*nn-1] by its discrete Cgrid transform if isign=1
  by its inverse "    "       "     if isign=-1
  nn MUST be an integer power of 2
  *data has de format 
  data[0]=Re(point0), data[1]=Im(point0)
  data[2]=Re(point1), data[3]=Im(point1)
  data[4]=Re(point2), data[5]=Im(point2)
  ...
  data[2*j]=Re(pointj), data[2*j+1]=Im(pointj)
*/
{
  int n, mmax, m, j, istep, i;
  real wtemp, wr, wpr, wpi, wi, theta;
  real tempr, tempi, aux;

  n = nn << 1;
  j = 1;

  for(i = 1; i < n; i += 2)
  {
    if(j > i)
    {
      aux = data[j-1];
      data[j-1] = data[i-1];
      data[i-1] = aux;
      aux = data[j];
      data[j] = data[i];
      data[i] = aux;
    }
    m = n >>1;
    while(m >= 2 && j > m)
    {
      j -= m;
      m >>= 1;
    }
    j += m;
  }
  mmax = 2;
  while(n > mmax)
  {
    istep = mmax << 1;
    theta = real(isign)*(pi2/(int)mmax);
    wtemp = sin(theta/val2);
    wpr = val0-val2*wtemp*wtemp;
    wpi = sin(theta);
    wr = val1;
    wi = val0;
    for(m = 1; m < mmax; m += 2)
    {
      for(i = m; i <= n; i += istep)
      {
        j = i+mmax;
        tempr = wr*data[j-1]-wi*data[j];
        tempi = wr*data[j]+wi*data[j-1];
        data[j-1] = data[i-1]-tempr;
        data[j] = data[i]-tempi;
        data[i-1] = data[i-1]+tempr;
        data[i] = data[i]+tempi;
      }
      wtemp = wr;
      wr = wtemp*wpr-wi*wpi+wr;
      wi = wi*wpr+wtemp*wpi+wi;
    }
    mmax = istep;
  }
  return ;
}

void fourn(real *data, int *nn, int ndim, int isign)
/*  
  Replaces data[0,...2*L-1] by its discrete Cgrid transform if isign=1
  by its inverse "    "       "     if isign=-1
  The inter L that defines the lengh of the array *data is 
  L=nn[0]*nn[1]*...*nn[ndim-1]
  nn[0..ndim-1] is an integer array containing the lenghs of 
  each dimension, which MUST be all integer powers of 2
  *data has de format of row-major order using that two consequtive real
  numbers correspond to a complex number. 
*/
{
  int idim;
  long int i1,i2,i3,i2rev,i3rev,ip1,ip2,ip3,ifp1,ifp2;
  long int ibit,k1,k2,n,nprev,nrem,ntot;
  real tempi,tempr,aux;
  real theta,wi,wpi,wpr,wr,wtemp;

  for (ntot=1,idim=1;idim<=ndim;idim++)
  ntot *= nn[idim-1];
  nprev=1;
  for (idim=ndim;idim>=1;idim--)
  {
    n=nn[idim-1];
    nrem=ntot/(n*nprev);
    ip1=nprev << 1;
    ip2=ip1*n;
    ip3=ip2*nrem;
    i2rev=1;
    for (i2=1;i2<=ip2;i2+=ip1)
    {
      if (i2 < i2rev)
      {
        for (i1=i2;i1<=i2+ip1-2;i1+=2)
        {
          for (i3=i1;i3<=ip3;i3+=ip2)
          {
            i3rev=i2rev+i3-i2;
            aux=data[i3-1];
            data[i3-1]=data[i3rev-1];
            data[i3rev-1]=aux;

            aux=data[i3];
            data[i3]=data[i3rev];
            data[i3rev]=aux;
          }
        }
      }
      ibit=ip2 >> 1;
      while (ibit >= ip1 && i2rev > ibit)
      {
        i2rev -= ibit;
        ibit >>= 1;
      }
      i2rev += ibit;
    }
    ifp1=ip1;
    while (ifp1 < ip2)
    {
      ifp2=ifp1 << 1;
      theta=real(isign)*pi2/(ifp2/ip1);
      wtemp=sin(theta/val2);
      wpr = -val2*wtemp*wtemp;
      wpi=sin(theta);
      wr= val1;
      wi= val0;
      for (i3=1;i3<=ifp1;i3+=ip1)
      {
        for (i1=i3;i1<=i3+ip1-2;i1+=2)
        {
          for (i2=i1;i2<=ip3;i2+=ifp2)
          {
            k1=i2;
            k2=k1+ifp1;
            tempr=wr*data[k2-1]-wi*data[k2];
            tempi=wr*data[k2]+wi*data[k2-1];
            data[k2-1]=data[k1-1]-tempr;
            data[k2]=data[k1]-tempi;
            data[k1-1] = data[k1-1]+tempr;
            data[k1] = data[k1]+tempi;
          }
        }
        wtemp=wr;
        wr=wtemp*wpr-wi*wpi+wr;
        wi=wi*wpr+wtemp*wpi+wi;
      }
      ifp1=ifp2;
    }
    nprev *= n;
  }
}

void parallel_perm_fourn(real *data, int *nn, int ndim, int isign, int nblocks, int precision)
{
  int *P, **cycle;
  char *moved;

  int p= nblocks, q= nn[0]/p;
  int nnp[ndim], nelem_blocks;

  P= (int *) calloc(nn[0], sizeof(int));
  for (int j= 0; j<p; j++)
  {
    for (int k= 0; k<q; k++)
    {   
      P[k+j*q]= j+k*p;	    
    }
  }
  cycle= (int **) calloc(nn[0], sizeof(int *));
  for (int i= 0; i<nn[0]; i++)
    cycle[i]= (int *) calloc(nn[0], sizeof(int));
  
  moved= (char *) calloc(nn[0], sizeof(char));
  for (int l= 0; l<nn[0]; l++)
    moved[l]= 0;

  int nc= 0, m0, sc;
  for (int m= 0; m<nn[0]; m++)
  {
    if (moved[m]) continue;

    m0= m;
    sc= 0;
    do 
    {
      sc++;
      cycle[nc][sc]= m0;
      moved[m0]= 1;
      m0= P[m0];	    
    }
    while (m0!= m);
    // cycle[nc][sc+1]= m0;
    cycle[nc][0]= sc; // tramaño del ciclo
    nc++;
  }

  //  nc= número de ciclos, puestos en cycle
  //  en el cycle i, cycle[i][0] es el número de elementos

  nnp[0]= q;
  for (int i= 1; i<ndim; i++)
  nnp[i]= nn[i];

  nelem_blocks= 1;
  for (int i= 1; i<ndim; i++)
  nelem_blocks*= nnp[i];

  #pragma omp parallel for 
  for (int i= 0; i<nc; i++)
  {
    mpfr_set_default_prec(precision);

    real aux;
    int sc= cycle[i][0];
    for (int j= 1; j<sc; j++)
    {
      real *d0, *d1;
      d0= data+2*(cycle[i][j]*nelem_blocks);
      d1= data+2*(cycle[i][j+1]*nelem_blocks);

      for (int l= 0; l<2*nelem_blocks; l++, d0++, d1++)
      {
        aux= *d0;
        *d0= *d1;
        *d1= aux;
      }
    }
  }
  mpfr_free_cache();

  free(P);
  free(moved);
  for (int l= 0; l<nn[0]; l++)
    free(cycle[l]);
  free(cycle);


  #pragma omp parallel for // num_threads(p)
  for (int j= 0; j<p; j++)
  {
    mpfr_set_default_prec(precision);
    fourn(data+2*nelem_blocks*q*j, nnp, ndim, isign);
  }
  mpfr_free_cache();

  real *wr, *wi;
  wr= new real[nn[0]];
  wi= new real[nn[0]];

  wr[0]= val1;
  wi[0]= val0;

  for (int i= 1; i<nn[0]; i++)
  {
    wr[i]= cos(real(i)*(pi2/nn[0]));
    wi[i]= real(isign)*sin(real(i)*(pi2/nn[0]));
  }

  #pragma omp parallel for // num_threads(p)
  for (int bk= 0; bk<q; bk++)
  {
    mpfr_set_default_prec(precision);

    real w[2], *y;
    y= new real[2*p];

    for (int l= 0; l<nelem_blocks; l++)
    {	   
      for (int bj= 0; bj<p; bj++)
      {
        int m= bk+bj*q;
        real *d;

        y[2*bj]= val0;
        y[2*bj+1]= val0;

        d= data+2*(nelem_blocks*bk+l); 
        for (int j= 0; j<p; j++, d+= 2*nelem_blocks*q)
        {  
          w[0]= wr[(j*m)%nn[0]];
          w[1]= wi[(j*m)%nn[0]];

          y[2*bj]= y[2*bj] + w[0]*d[0]-w[1]*d[1];
          y[2*bj+1]= y[2*bj+1] + w[0]*d[1]+w[1]*d[0];
        }
      }
      real *d;
      d= data+2*(nelem_blocks*bk+l);
      for (int bj= 0; bj<p; bj++, d+= 2*nelem_blocks*q)
      {
        d[0]= y[2*bj];
        d[1]= y[2*bj+1];
      }
    }
    delete [] y; 
  } 
  mpfr_free_cache();

  delete [] wr;
  delete [] wi;
}

void cfourn(complex *data, int *nn, int ndim, int isign)
/*  
  Replaces data[0,...L-1] by its discrete Fourier transform if isign=1
  by its inverse "    "       "     if isign=-1
  The inter L that defines the lengh of the array *data is 
  L=nn[0]*nn[1]*...*nn[ndim-1]
  nn[0..ndim-1] is an integer array containing the lenghs of 
  each dimension, which MUST be all integer powers of 2
  *data has de format of row-major order. 
*/
{
  int idim;
  long int i1,i2,i3,i2rev,i3rev,ip1,ip2,ip3,ifp1,ifp2; 
  long int ibit,n,nprev,nrem,ntot;
  real tempi,tempr;
  real theta,wi,wpi,wpr,wr,wtemp;
  complex aux, temp, wp, w;

  for (ntot=1,idim=0;idim<ndim;idim++)
    ntot *= nn[idim];
  nprev=1;
  for (idim=ndim-1;idim>= 0;idim--)
  {
    n=nn[idim];
    nrem=ntot/(n*nprev);
    ip1=nprev << 1;
    ip2=ip1*n;
    ip3=ip2*nrem;

    i2rev=1;
    for (i2=1;i2<=ip2;i2+=ip1)
    {     
      if (i2 < i2rev)
      {
        for (i1=i2;i1<=i2+ip1-2;i1+=2)
        {
          for (i3=i1;i3<=ip3;i3+=ip2)
          {
            i3rev=i2rev+i3-i2;
            int j3= (i3-1)/2, j3rev= (i3rev-1)/2;

            aux= data[j3];
            data[j3]= data[j3rev];
            data[j3rev]= aux;
          }
        }
      }
      ibit= ip2 >> 1;	    
      while (ibit >= ip1 && i2rev>ibit) 
      {
        i2rev -= ibit;
        ibit >>= 1;		
      }
      i2rev += ibit; 
    }
    ifp1=ip1;
    while (ifp1 < ip2)
    {
      ifp2=ifp1 << 1;
      theta=real(isign)*pi2/(ifp2/ip1);
      wtemp= sin(theta/val2);

      wp.re= -val2*wtemp*wtemp;
      wp.im= sin(theta);

      w.re = val1;
      w.im= val0;

      for (i3=1;i3<=ifp1;i3+=ip1)
      {
        for (i1=i3;i1<=i3+ip1-2;i1+=2)
        {
          for (i2=i1;i2<=ip3;i2+=ifp2)
          {
            int j1, j2;
            j1= (i2-1)>>1;
            j2= j1 + (ifp1>>1);
            temp= w*data[j2];
            data[j2]= data[j1]-temp;
            data[j1]= data[j1]+temp;
          }
        }

        w= w + w*wp;		
      }
      ifp1=ifp2;
    }
    nprev *= n;
  }
}

void parallel_perm_cfourn(complex *data, int *nn, int ndim, int isign, int nblocks, int precision)
{
  int *P, **cycle;
  char *moved;

  int p= nblocks, q= nn[0]/p;
  int nnp[ndim], nelem_blocks;

  P= (int *) calloc(nn[0], sizeof(int));
  for (int j= 0; j<p; j++)
  {
    for (int k= 0; k<q; k++)
    {   
      P[k+j*q]= j+k*p;	    
    }
  }
  cycle= (int **) calloc(nn[0], sizeof(int *));
  for (int i= 0; i<nn[0]; i++)
    cycle[i]= (int *) calloc(nn[0], sizeof(int));
  
  moved= (char *) calloc(nn[0], sizeof(char));
  for (int l= 0; l<nn[0]; l++)
    moved[l]= 0;

  int nc= 0, m0, sc;
  for (int m= 0; m<nn[0]; m++)
  {
    if (moved[m]) continue;

    m0= m;
    sc= 0;
    do 
    {
      sc++;
      cycle[nc][sc]= m0;
      moved[m0]= 1;
      m0= P[m0];	    
    }
    while (m0!= m);
    // cycle[nc][sc+1]= m0;
    cycle[nc][0]= sc; // tamaño del ciclo
    nc++;
  } 

  //  nc= número de ciclos, puestos en cycle
  //  en el cycle i, cycle[i][0] es el número de elementos

  nnp[0]= q;
  for (int i= 1; i<ndim; i++)
    nnp[i]= nn[i];

  nelem_blocks= 1;
  for (int i= 1; i<ndim; i++)
    nelem_blocks*= nnp[i];

  #pragma omp parallel for 
  for (int i= 0; i<nc; i++)
  {
    mpfr_set_default_prec(precision);

    complex aux;
    int sc= cycle[i][0];
    for (int j= 1; j<sc; j++)
    {
      complex *d0, *d1;
      d0= data+(cycle[i][j]*nelem_blocks);
      d1= data+(cycle[i][j+1]*nelem_blocks);

      for (int l= 0; l<nelem_blocks; l++, d0++, d1++)
      {
        aux= *d0;
        *d0= *d1;
        *d1= aux;
      }
    }
  }
  mpfr_free_cache();

  free(P);
  free(moved);
  for (int l= 0; l<nn[0]; l++)
    free(cycle[l]);
  free(cycle);

  #pragma omp parallel for // num_threads(p)
  for (int j= 0; j<p; j++)
  {
    mpfr_set_default_prec(precision);
    cfourn(data+nelem_blocks*q*j, nnp, ndim, isign);
  }
  mpfr_free_cache();

  complex *w;
  w= new complex[nn[0]]; 

  w[0].re= val1;
  w[0].im= val0;

  for (int i= 1; i<nn[0]; i++)
  {
    w[i].re= cos(real(i)*(pi2/nn[0]));
    w[i].im= real(isign)*sin(real(i)*(pi2/nn[0]));
  }

  #pragma omp parallel for // num_threads(p)
  for (int bk= 0; bk<q; bk++)
  {
    mpfr_set_default_prec(precision);

    complex *y;
    y= new complex[p];

    for (int l= 0; l<nelem_blocks; l++)
    {	   
      for (int bj= 0; bj<p; bj++)
      {
        int m= bk+bj*q;
        complex *d;

        y[bj].re= val0;
        y[bj].im= val0;

        d= data+(nelem_blocks*bk+l); 
        for (int j= 0; j<p; j++, d+= nelem_blocks*q)
        {  	    
          y[bj]= y[bj] + w[(j*m)%nn[0]]*(*d);
        }
      }
      complex *d;
      d= data+(nelem_blocks*bk+l);
      for (int bj= 0; bj<p; bj++, d+= nelem_blocks*q)
      {
        *d= y[bj];
      }
    }
    delete [] y;
  } 
  mpfr_free_cache();

  delete [] w;
}

// inplace version
void infft_F(cgrid& g)
{
  if (g.ndim==1) four1((real *) g.elem,g.nelem,-1);
  else fourn((real *) g.elem, g.nn,g.ndim,-1);
  //else parallel_perm_cfourn(g.elem, g.nn,g.ndim,-1, nblocks);
  //else parallel_perm_fourn((real *) g.elem, g.nn,g.ndim,-1, nblocks);

  for (int i=0;i<g.nelem;i++)
  {
    g.elem[i].re = g.elem[i].re/g.nelem;
    g.elem[i].im = g.elem[i].im/g.nelem;
  }
}
    
void infft_B(cgrid& f)
{
  if (f.ndim==1) four1((real *) f.elem,f.nelem,1);
  else fourn((real *) f.elem,f.nn,f.ndim,1);
  // else parallel_perm_cfourn(f.elem,f.nn,f.ndim,1, nblocks);
  //else parallel_perm_fourn((real *) f.elem,f.nn,f.ndim,1, nblocks);
}

// fill version
void fft_F(const grid& g, fourier& f)
{
  for (int i=0;i<g.nelem;i++)
  {
    f.elem[i].re = g.elem[i];  //g.elem[i].re;
    f.elem[i].im = val0;//g.elem[i].im;
    // Alex: data is real
  }

  if (g.ndim==1) four1((real *) f.elem,g.nelem,-1);
  else fourn((real *) f.elem,f.nn,f.ndim,1);
  //else parallel_perm_fourn((real *) f.elem, g.nn,g.ndim,-1, nblocks);

  for (int i=0;i<g.nelem;i++)
  {
    f.elem[i].re = f.elem[i].re/g.nelem;
    f.elem[i].im = f.elem[i].im/g.nelem;
  }

  clean_nyquist(f); // Assume real data
}

void fft_B(const fourier& f, grid& g)
{
  cgrid fg;

  fg= f; // Aquí se genera memoria ... Con reallocs?
  infft_B(fg);  
  for (int i=0;i<g.nelem;i++)
  {
    g.elem[i]= fg.elem[i].re;	
  // Alex: data is real
  }
}

// generate objects
fourier fft_F(const grid& g)
{
  cgrid fg(g.ndim,g.nn);
  real *data, tot;

  data = (real *) fg.elem; // new real [2*g.nelem];
  for (int i=0;i<g.nelem;i++)
  {
    data[2*i] = g.elem[i];  //g.elem[i].re;
    data[2*i+1] = val0;//g.elem[i].im;
    // Alex: data is real
  }
  if (g.ndim==1) four1(data,g.nelem,-1);
  else fourn(data,g.nn,g.ndim,-1);
  //else parallel_perm_fourn(data,g.nn,g.ndim,-1, nblocks);
  tot=g.nelem;
  for (int i=0;i<g.nelem;i++)
  {
    fg.elem[i].re = data[2*i]/tot;
    fg.elem[i].im = data[2*i+1]/tot;
  }

  // Alex: Assume data is real
  clean_nyquist(fg);

  // delete [] data;
  return fg;
}

grid fft_B(const fourier &f)
{
  grid gf(f.ndim,f.nn);
  real *data;

  data = new real [2*f.nelem]; // extra memory
  for (int i=0;i<f.nelem;i++)
  {
    data[2*i]   = f.elem[i].re;
    data[2*i+1] = f.elem[i].im;
  }
  if (f.ndim==1) four1(data, f.nelem, 1);
  else fourn(data, f.nn, f.ndim, 1);
  //else parallel_perm_fourn(data,f.nn,f.ndim,1,nblocks);
  for (int i=0;i<f.nelem;i++)
  {
    gf.elem[i] = data[2*i];
    // gf.elem[i].im = data[2*i+1];
    // Alex: Assume the data is real
  }

  delete [] data;
  return gf;
}

void initialize_index_grid(int *index, int ndim, int *nn)
{
  for(int k = 0; k < ndim; k++) index[k]= 0;
}

void next_index_grid(int *index, int ndim, int *nn)
{
  for(int k= ndim-1; k>=0; k--) 
  {
    index[k] += 1;
    if(index[k]== nn[k])
      index[k]= 0;
    else
    break;
  }
}

void initialize_index_fourier(int *index, int ndim, int *nn)
{
  for(int k= 0; k< ndim; k++) index[k]= 0;
}

void next_index_fourier(int *index, int ndim, int *nn)
{
  for(int k= ndim-1; k>=0; k--) 
  {
    index[k]+= 1;

    if (index[k]== nn[k]/2) 
    {
      index[k]= -index[k];
      break;
    }

    if (index[k]!= 0) break;
  }
}

void clean(cgrid& g)
{
  for(int l=0;l<g.nelem;l++)
    if (abs(g.elem[l])<tolcoho)
      g.elem[l]= val0;
}

void clean_tail(cgrid& f) 
{
  int *index;

  index = new int[f.ndim]; 
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++) 
  {
    for (int k= 0; k<f.ndim; k++) 
    {
      //  if(index[k]>=f.nn[k]/4 || index[k]<=-f.nn[k]/4){
      if(index[k]>=3*(f.nn[k]/8) || index[k]<=-3*(f.nn[k]/8))
      {
        f.elem[i].re= val0;
        f.elem[i].im= val0;
        break;
      }
    }  
    next_index_fourier(index, f.ndim, f.nn);
  }

  delete [] index;
}

void super_clean_tail (fourier &f, int *filter)
{
  int *index;

  index = new int[f.ndim]; 
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++) 
  {
    for (int k= 0; k<f.ndim; k++) 
    {
      //  if(index[k]>=f.nn[k]/4 || index[k]<=-f.nn[k]/4){
      if(index[k]>= filter[k] || index[k]<= -filter[k])
      {
        f.elem[i].re= val0;
        f.elem[i].im= val0;
        break;
    }
  }  
  next_index_fourier(index, f.ndim, f.nn);
}

delete [] index;
}

cgrid get_tail(cgrid& f) 
{
  cgrid tf(f.ndim,f.nn);
  int *index;

  index = new int[f.ndim]; 
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++) 
  {
    for(int k= 0; k<f.ndim; k++) 
    {
      if(index[k]>=f.nn[k]/4 || index[k]<=-f.nn[k]/4)
      {
        tf.elem[i]= f.elem[i];
        break;
      }
      else
      tf.elem[i]= val0;    
    }  
    next_index_fourier(index, f.ndim, f.nn);
  }

  delete [] index;

  return tf;    
}

void clean_nyquist(cgrid& f) // Niquist a zero, para realificar
{
  int *index;

  index = new int[f.ndim];
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++)
  { 
    for(int k= 0; k<f.ndim; k++) 
    {
      if(index[k]== -f.nn[k]/2) 
      {
        f.elem[i]= val0;
        break;
      }
    }
    next_index_fourier(index, f.ndim, f.nn);
  }

  delete [] index;
}

cgrid get_nyquist(cgrid& f)
{
  cgrid nf(f.ndim,f.nn);
  int *index;

  index = new int[f.ndim];
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++)
  { 
    for(int k= 0; k<f.ndim; k++)
    { 
      if(index[k]== -f.nn[k]/2)
      {
        nf.elem[i]= f.elem[i];
        break;
      }
      else
      nf.elem[i]= val0;
    }
    next_index_fourier(index, f.ndim, f.nn);
  }

  delete [] index;
  return nf;
}

real norm_nyquist(cgrid& f)
{
  real l1nf;
  int *index;

  l1nf= val0;
  index = new int[f.ndim];
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i=0; i<f.nelem; i++)
  { 
    for(int k= 0; k<f.ndim; k++) 
    {
      if(index[k]== -f.nn[k]/2) 
      {
        l1nf= l1nf + abs(f.elem[i]);
        break;
      }
    }
    next_index_fourier(index, f.ndim, f.nn);
  }

  delete [] index;
  return l1nf;
}

real norm_nyquist(grid& g)
{
  real ng;
  cgrid fg(g.ndim,g.nn);  
  fg= fft_F(g);
  ng= norm_nyquist(fg);  // no funciona norm_nyquist(fft_B(g)); ? 
  return ng;
}

real tail(const cgrid& f, real *tf)
{
  int *index, *nelemtail, nelemmtail= 0;
  real mtf;

  mtf= val0;

  index = new int[f.ndim];
  initialize_index_fourier(index, f.ndim, f.nn);

  nelemtail = new int[f.ndim];  
  for(int k= 0; k<f.ndim; k++) 
    nelemtail[k]= 0;

  for(int k= 0; k<f.ndim; k++) 
    tf[k] = val0;

  for(int l= 0; l<f.nelem; l++)
  {
    for(int k= 0; k < f.ndim; k++)
    {
      if(index[k]>=f.nn[k]/4 || index[k]<=-f.nn[k]/4)
      {
        tf[k] = tf[k]+abs(f.elem[l]);
        nelemtail[k]++;
      }
    }

    for(int k = 0; k < f.ndim; k++)
    {
      if(index[k]>=f.nn[k]/4 || index[k]<=-f.nn[k]/4)
      {
        mtf = mtf+abs(f.elem[l]);
        nelemmtail++;
        break;
      }
    }

    next_index_fourier(index, f.ndim, f.nn);
  }

  //for(int k = 0; k < f.ndim; k++) tf[k] = tf[k]/nelemtail[k];
  //mtf= mtf/nelemmtail;

  delete [] index;
  delete [] nelemtail;

  return mtf;
}

void clean(grid& g)
{
  cgrid gF(g.ndim,g.nn);

  gF= fft_F(g);
  clean(gF);
  g= fft_B(gF);
}

void clean_tail(grid& g)
{
  cgrid gF(g.ndim,g.nn);

  gF= fft_F(g);
  clean_tail(gF);
  g= fft_B(gF);
}


void clean_nyquist(grid& g)
{
  cgrid gF(g.ndim,g.nn);

  gF= fft_F(g);
  clean_nyquist(gF);
  g= fft_B(gF);
}

real tail(const grid& g, real *tg)
{
  return tail(fft_F(g), tg);
}
  
// Alex: No la he cambiado todavia
void obtain_real_analytic(grid& g)
{
  int flag;
  int *index;
  int *index_serie;

  index=new int[g.ndim];
  index_serie=new int[g.ndim];

  for(int i=0;i<g.nelem;i++)
  {
    indices(i,g.nn,index,g.ndim);
    trigo_to_series(g.nn,index,index_serie,g.ndim);
    flag=0;
    for(int j=0;j<g.ndim;j++)
    {
      if (index_serie[j]> g.nn[j]/4) flag=1;
      if (index_serie[j]<-g.nn[j]/4) flag=1;
    }
    if (flag==1)
    {
      g.elem[i]=val0;
    }
  }

  delete [] index;
  delete [] index_serie;
}

real norm(const grid& g)
{
  real sg, ag;

  sg = val0;
  for(int l = 0; l < g.nelem; l++) 
  {
    ag = abs(g.elem[l]);
    if(ag > sg) sg = ag;
  }

  return sg;
}

real norm(const cgrid& g)
{
  real sg, ag;

  sg = val0;
  for(int l=0;l<g.nelem;l++) 
  {
    ag= abs(g.elem[l]);
    if (ag>sg) sg= ag;
  }

  return sg;
}

real dist(const grid& g1, const grid& g2)
{
  real sg, ag;

  sg = val0;

  if (g1.ndim!=g2.ndim || g1.nelem!=g2.nelem)
    cout << "grid dist: error en las dimensiones" << endl;

  for(int l=0;l<g1.nelem;l++)
  {
    ag = abs(g1.elem[l]-g2.elem[l]);
    if (ag>sg) sg= ag;
  }

  return sg;
}

real norml1(const cgrid& f)
{
  real l1f;
  l1f= val0;

  for(int l=0;l<f.nelem;l++)
    l1f= l1f + abs(f.elem[l]);

  return l1f;
}

real dist(const cgrid& f1, const cgrid& f2)
{
  real l1f;
  l1f= val0;

  if (f1.ndim!=f2.ndim || f1.nelem!=f2.nelem)
    cout << "cgrid dist: error en las dimensiones" << endl;

  for(int l=0;l<f1.nelem;l++)
    l1f= l1f + abs(f1.elem[l]-f2.elem[l]);

  return l1f;
}

void aver(const grid& g, real &avg)
{
  avg = val0;

  for(int l = 0; l < g.nelem; l++)
    avg = avg+g.elem[l];

  avg = avg/real(g.nelem);
}

real aver(const grid& g)
{
  real avg;

  avg = val0;

  for(int l=0; l<g.nelem; l++)
    avg = avg + g.elem[l];

  avg = avg/real(g.nelem);

  return avg;
}

void aver(const cgrid& g, complex &avg)
{
  avg.re = val0;
  avg.im = val0;

  for(int l=0; l<g.nelem; l++)
    avg = avg + g.elem[l];

  avg = avg/real(g.nelem);
}

complex aver(const cgrid& g)
{
  complex avg;
  avg.re = val0;       
  avg.im = val0;

  for(int l=0; l<g.nelem; l++)
    avg = avg + g.elem[l];

  avg = avg/real(g.nelem);
  return avg;
}

void trigo_to_series(int *nn, int *index, int *indexserie, int ndim)
{
  for(int i=0;i<ndim;i++)
  {
    if (index[i]==0) indexserie[i]=0;
    else if(index[i]<nn[i]/2) indexserie[i]=index[i];
    else indexserie[i]=index[i]-nn[i];
  }
}

void series_to_trigo(int *nn, int *indexserie, int *index, int ndim)
{
  for(int i=0;i<ndim;i++)
  {
    if (indexserie[i]==0) index[i]=0;
    else if(indexserie[i]>0) index[i]=indexserie[i];
    else index[i]=indexserie[i]+nn[i];
  }
}

int position(int *nn, int *index, int ndim)
// Esta rutina es muy mala ... Se puede hacer "Horner"
// pos= i[0] *(n[1] * ... * n[d-1]) + i1 * (n[2]* ... *n[d-1]) + ... + i[d-1]
//    = i[d-1] + n[d-1]*(i[d-2] + n[d-2]*(i[d-3] + ... n[1]*i[0]))
{
  int pos;

  pos= index[0];
  for (int k= 1; k<ndim; k++)
  {
    pos= pos*nn[k]+index[k];
  }
  return pos;
}

void indices(int pos, int *nn, int *index, int ndim)
{
  int pos0 = pos;

  for(int k = ndim-1; k > 0; k--)
  {
    index[k] = pos0%nn[k];
    pos0 = pos0/nn[k];
  }
  index[0] = pos0;

  return ;
}

// derivative with respect to theta_m
void inderivative(const fourier& f, int m)  // inplace version
{
  int *index;
  real aux, dfreal, dfimag;

  index = new int[f.ndim];
  initialize_index_fourier (index, f.ndim, f.nn);

  for(int i = 0; i < f.nelem; i++)
  {
    aux= index[m];  
    dfreal= -aux*f.elem[i].im;
    dfimag=  aux*f.elem[i].re;
    f.elem[i].re = dfreal;
    f.elem[i].im = dfimag;

    next_index_fourier (index, f.ndim, f.nn);
  }

  delete [] index;
}

void derivative(const fourier& f, int m, fourier& df)
{
  int *index;
  real aux, dfreal, dfimag;

  index = new int[f.ndim];
  initialize_index_fourier(index, f.ndim, f.nn);

  for(int i = 0; i < f.nelem; i++)
  {
    aux = index[m];  
    //df.elem[i] = complex(val0, aux)*f.elem[i];
    dfreal= -aux*f.elem[i].im;
    dfimag=  aux*f.elem[i].re;
    df.elem[i].re = dfreal;
    df.elem[i].im = dfimag;

    next_index_fourier (index, f.ndim, f.nn);
  }

  delete [] index;
}

fourier derivative(const fourier& f, int m)
/*
  Given a grid of Cgrid coefficients of a ndim-periodic function
  we compute the derivative with respect to theta_m
*/
{
  if (m>=f.ndim) cout << "Problema con los indices en derivadas" << endl;

  int *index;
  real aux;
  cgrid df(f.ndim, f.nn);

  index = new int[f.ndim];
  initialize_index_fourier (index, f.ndim, f.nn);

  for(int i = 0; i < f.nelem; i++)
  {
    aux= index[m];  
    //df.elem[i] = complex(val0, aux)*f.elem[i];
    df.elem[i].re = -aux*f.elem[i].im;
    df.elem[i].im =  aux*f.elem[i].re;

    next_index_fourier (index, f.ndim, f.nn);
  }

  delete [] index;

  return df;
}

grid derivative (const grid& g, int k)
{
  fourier f;

  f= fft_F(g);
  inderivative(f, k);

  return fft_B(f);
}

// Russmann operator, continuous case
fourier Ropc (const fourier& f, real *omega)
/*
  Given a grid of Cgrid coefficients of a ndim-periodic function
  we compute the solution of the 1-bite cohomological equation
*/
{
  int *index;
  real aux;
  cgrid Ropcf(f.ndim, f.nn);

  index=new int[f.ndim];
  initialize_index_fourier (index, f.ndim, f.nn);

  Ropcf.elem[0]= val0;
  next_index_fourier (index, f.ndim, f.nn);

  for(int i=1;i<f.nelem;i++)
  {
    aux=val0;
    for(int j=0;j<f.ndim;j++) aux = aux + real(index[j])*omega[j];

    if (abs(f.elem[i])>tolcoho) 
    {
      Ropcf.elem[i]= f.elem[i]/(complex(val0, -aux));
    }
    else
      Ropcf.elem[i]= val0;

    //Ropcf.elem[i].re = -f.elem[i].im/aux;
    //Ropcf.elem[i].im =  f.elem[i].re/aux;

    next_index_fourier (index, f.ndim, f.nn);
  }

  delete [] index;

  return Ropcf;
}

void inRopc (const fourier& f, real *omega)
/*
  Given a grid of Cgrid coefficients of a ndim-periodic function
  we compute the solution of the 1-bite cohomological equation
*/
{
  int *index;
  real aux, Ropcfreal, Ropcfimag;

  index=new int[f.ndim];
  initialize_index_fourier (index, f.ndim, f.nn);

  f.elem[0].re= val0;
  f.elem[0].im= val0;
  next_index_fourier (index, f.ndim, f.nn);

  for(int i=1;i<f.nelem;i++)
  {
    aux=val0;
    for(int j=0;j<f.ndim;j++) aux = aux + real(index[j])*omega[j];

    if (abs(f.elem[i])>tolcoho) 
    {
      Ropcfreal= -f.elem[i].im/aux;
      Ropcfimag=  f.elem[i].re/aux; 
      f.elem[i].re = Ropcfreal;
      f.elem[i].im = Ropcfimag;
    }
    else
    {
      f.elem[i].re= val0;
      f.elem[i].im= val0;
    }

    next_index_fourier (index, f.ndim, f.nn);
  }

  delete [] index;
}

grid Ropc(const grid& g, real *omega)
{
  fourier f;
  f= fft_F(g);
  inRopc(f,omega);
  return fft_B(f);
}

void zerogrid(grid& g)
{
  for(int i=0;i<g.nelem;i++) g.elem[i]= val0;
}

void constantgrid(grid& g, real& x)
{
  for(int i=0;i<g.nelem;i++) g.elem[i]= x;
}

void zerocgrid(cgrid& f)
{
  complex zero= complex(val0,val0);

  for(int i=0;i<f.nelem;i++) f.elem[i]= zero;
}

void constantcgrid(cgrid& f, complex& z)
{
  complex zero= complex(val0,val0);
  f.elem[0]= z;
  for(int i=1;i<f.nelem;i++) f.elem[i]= zero;
} 

void constantcgrid(cgrid& f, real& x)
{
  complex zero= complex(val0,val0);
  f.elem[0]= complex(x,val0);
  for(int i=1;i<f.nelem;i++) f.elem[i]= zero;
} 

void start_grid(const real& tol)
{
  tolcoho=tol;
}

// NEW Fourier Modes
grid fourier_modes (const fourier& f, int nvar)
{
  int *index, ll;
  grid fm(1, &(f.nn[nvar]));

  index = new int[f.ndim];
  initialize_index_fourier (index, f.ndim, f.nn);

  for(int l=0;l<f.nelem;l++)
  {
    //	ll= index[nvar] + (f.nn[nvar])/2;
    // Se añade f.nn[nvar]/2 para que ll empiece en 0

    ll= index[nvar];
    if (ll<0)
      ll= ll + (f.nn[nvar]);

    fm.elem[ll]= fm.elem[ll] + abs(f.elem[l]);

    next_index_fourier (index, f.ndim, f.nn);
  }
  delete [] index;

  return fm;
}

/*------------------------------*/
}
