/*
 * realmp_io.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "realmp_io.h"

int digits_printf = 8;
std::ostream& operator<<(std::ostream& os, const real& obj)
{
  char name[200];
  sprintf(name, "%c .%dRe", '\%', digits_printf);
  mpfr_printf(name, obj.x);
  return os;
}

void print_matrix_real(real **m, int nrows, int ncols)
{
  for (int i=0;i<nrows;i++)
  {
    for (int j=0;j<ncols;j++)
    {
      cout << m[i][j] << " ";
    }
    cout << endl;
  }
}

void real_scanf(real &x, int digits)
{
  char buf[2*digits];
  scanf("%s", buf);
  mpfr_set_str(x.x, buf, 10, GMP_RNDN);
}

void real_printf(const real& x, int digits)
{
  char format[2*digits];
  sprintf(format, "%c .%dRe", '\%', digits); 
  mpfr_printf(format, x.x);
}

void real_fscanf(FILE *pfile, real &x, int digits)
{
  char buf[2*digits];
  fscanf(pfile, "%s", buf);
  mpfr_set_str(x.x, buf, 10, GMP_RNDN);
}

void real_fprintf(FILE *pfile, const real& x, int digits)
{
  char format[2*digits];
  sprintf(format, "%c.%dRe", '\%', digits); 
  mpfr_fprintf(pfile, format, x.x);
}

void real_sscanf(char *buf, real &x, int digits = 0)
{    
  scanf("%s", buf);
  mpfr_set_str(x.x, buf, 10, GMP_RNDN);
}

void real_sprintf(char *buf, real& x, int digits)
{
  char format[10];
  sprintf(format, "%c.%dRe", '\%', digits); 
  mpfr_sprintf(buf, format, x.x);
}

long double realtold(const real& x)
{
  return mpfr_get_ld(x.x, GMP_RNDN);
}

real strtoreal(char *buf)
{
  real x(buf);
  return x;
}

int fwrite_real(mpfr_t *x, int N, FILE *fp)
{
  int i, res;
  res = 0;

  for(i = 0; i < N; i++)
  {
    res = mpfr_fpif_export(fp, x[i]);
    if(res != 0)
    {
      return res;
    }
  }
  return res;
}

int fwrite_real(real *x, int N, FILE *fp)
{
  int i, res;
  res = 0;

  for(i = 0; i < N; i++)
  {
    res = mpfr_fpif_export(fp, x[i].x);
    if(res != 0)
    {
      return res;
    }
  }

  return res;
}

int fread_real(mpfr_t *x, int N, FILE *fp)
{
  int i, res;
  res = 0;

  for(i = 0; i < N; i++)
  {
    res = mpfr_fpif_import(x[i], fp);
    if(res != 0)
    {
      return res;
    }
  }

  return res;
}

int fread_real(real *x, int N, FILE *fp)
{
  int i, res;
  res = 0;

  for(i = 0; i < N; i++)
  {
    res = mpfr_fpif_import(x[i].x, fp);
    if(res != 0)
    {
      return res;
    }
  }

  return res;
}


