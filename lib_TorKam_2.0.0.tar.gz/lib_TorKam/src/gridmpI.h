/*
 * gridinterval.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef GRIDINTERVAL_H
#define GRIDINTERVAL_H

#define GRIDINTERVAL_VERSION 2.0

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <cstring>

#include "complexinterval.h"

using namespace std;

extern int precision;
extern int nblocks;

class gridI
{
public:
    
    int ndim;
    int nelem;
    int *nn;
    myrealI *elem;
    
    gridI();
    gridI(const gridI& y);
    gridI(int d, int *n);
    ~gridI();
    
    gridI& operator = (const gridI& g);
    
    void alloc_gridI()
    {
        nn=new int[ndim];
        elem=new myrealI[nelem];
    }
};

class cgridI
{
public:
    
    int ndim;
    int nelem;
    int *nn;
    complexI *elem;
    
    cgridI();
    cgridI(const cgridI& y);
    cgridI(int d, int *n);
    ~cgridI();
    
    cgridI& operator = (const cgridI& f);
    
    void alloc_cgridI()
    {
        nn=new int[ndim];
        elem=new complexI[nelem];
    }
};

typedef cgridI fourier;

// Real and imaginary parts of complexI gridIs. Fill version
void realpart(const cgridI& g, gridI& rg);
void imagpart(const cgridI& g, gridI& ig);
void assign_realpart(const gridI& rg, cgridI& g);
void assign_imagpart(const gridI& ig, cgridI& g);


// FFT
//numerical recipes
void four1(myrealI *data, int nn, int isign);
void fourn(myrealI *data, int *nn, int ndim, int isign);
void parallel_perm_fourn(myrealI *data, int *nn, int ndim, int isign, int nblocks);

// inplace version
void infft_F(cgridI& g); 
void infft_B(cgridI& f);

// fill objects
void fft_F(const gridI& g, fourier& f);
void fft_B(const fourier& f, gridI& g);

// generate objects
fourier fft_F(const gridI& g);
gridI fft_B(const fourier& f);



void trigo_to_series(int *nn, int *index, int *indexserie, int ndim);
void series_to_trigo(int *nn, int *indexserie, int *index, int ndim);
int position(int *nn, int *index, int ndim);
void indices(int pos, int *nn, int *index, int ndim);

void initialize_index_gridI(int *index_gridI, int ndim, int *nn);
void next_index_gridI (int *index_gridI, int ndim, int *nn);
void initialize_index_fourier (int *index_fourier, int ndim, int *nn);
void next_index_fourier (int *index_fourier, int ndim, int *nn);

// derivative with respect to theta_m
void inderivative(const fourier& f, int m); // inplace version
fourier derivative (const fourier& f, int m); // generate version 
void derivative(const fourier& f, int m, const fourier& df); //fill version
gridI derivative(const gridI& g, int m); // generate version
void derivative(const gridI& g, int m, const gridI& dg); // fill version

#define inRopcF inRopc
void inRopc(const fourier& f, myrealI *omega); // inplace version
fourier Ropc(const fourier& f, myrealI *omega); // generate version
void Ropc(const fourier& f, myrealI *omega, const fourier& Ropcf); //fill version 
gridI Ropc(const gridI& g, myrealI *omega); // genererate version
gridI Ropc(const gridI& g, myrealI *omega, const gridI& Ropcg);  //fill version

// gridI shift (const gridI& g, myrealI *omega);
//gridI shiftc (const gridI& g, const myrealI &rho);



void zerogridI(gridI& g);
void constantgridI(gridI& g, myrealI& x);
void zerocgridI(cgridI& f);
void constantcgridI(cgridI& f, complexI& z);
void constantcgridI(cgridI& f, myrealI& x);

void clean (cgridI& f);
void clean_tail(cgridI& f);
void super_clean_tail (cgridI &f, int *flt);
cgridI get_tail(cgridI& f);
void clean_nyquist(cgridI& f); 
cgridI get_nyquist(cgridI& f);
myrealI norm_nyquist(cgridI& f);
myrealI tail(const cgridI& f, myrealI *tf);



void clean(gridI& g);
void clean_tail(gridI& g);
void clean_nyquist(gridI& g);
myrealI norm_nyquist(gridI& g);
myrealI tail(const gridI& g, myrealI *tg);
  
//void obtain_real_analitic(gridI& g);

void aver(const gridI& g, myrealI &avg);
myrealI aver(const gridI& g);
void aver(const cgridI& f, complexI &avg);
complexI aver(const cgridI& f);

myrealI norm(const gridI& g);
myrealI norm(const cgridI& f);

/*
  myrealI normsobo(const gridI& g, const myrealI& r);
  myrealI normsup(const gridI& g, const myrealI& rho);
  myrealI normexp(const gridI& g, const myrealI& rho);
*/

void print_gridI(const gridI& g);
void print_cgridI(const cgridI& f);

void fread_gridI(const gridI& g, FILE *fg);
void fwrite_gridI(const gridI& g, FILE *fg);


myrealI tolcoho;

gridI::gridI()
{
    ndim=0;
    nelem=0;
    nn=NULL;
    elem=NULL;
}

gridI::gridI(int dim, int *n)
{
    ndim=dim;
    nelem=1;
    for(int i=0;i<ndim;i++) nelem = nelem*n[i];
    alloc_gridI();
    for(int i = 0; i < ndim; i++) nn[i] = n[i];
    for(int i = 0; i < nelem; i++) elem[i] = val0;
}

gridI::gridI(const gridI& y)
{
    ndim=y.ndim;
    nelem=y.nelem;

    alloc_gridI();
    for(int i=0;i<ndim;i++) nn[i] = y.nn[i];
    for(int i=0;i<nelem;i++) elem[i] = y.elem[i];
}

gridI::~gridI()
{
    if(nn!=NULL)
    {
        delete [] nn;
    }
    if(elem!=NULL)
    {
        delete [] elem;
    }
}

inline gridI& gridI::operator = (const gridI& y)
{
    if (this == &y)
    {
        return *this;
    }
    else
    {
        if (ndim!=y.ndim || nelem!=y.nelem)
        {
            this->~gridI();
            ndim=y.ndim;
            nelem=y.nelem;
            alloc_gridI();
        }
        for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
        for(int i=0;i<nelem;i++) elem[i]=y.elem[i];

        return *this;
    }
}
    
    cgridI::cgridI()
    {
	ndim=0;
	nelem=0;
	nn=NULL;
	elem=NULL;
    }

cgridI::cgridI(int dim, int *n)
{
    ndim=dim;
    nelem=1;
    for(int i=0;i<ndim;i++) nelem = nelem*n[i];
    alloc_cgridI();
    for(int i = 0; i < ndim; i++) nn[i] = n[i];
    for(int i = 0; i < nelem; i++) elem[i] = val0;
}

cgridI::cgridI(const cgridI& y)
{
    ndim=y.ndim;
    nelem=y.nelem;

    alloc_cgridI();
    for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
    for(int i=0;i<nelem;i++) elem[i]=y.elem[i];
}

cgridI::~cgridI()
{
    if(nn!=NULL)
    {
        delete [] nn;
    }
    if(elem!=NULL)
    {
        delete [] elem;
    }
}

inline cgridI& cgridI::operator = (const cgridI& y)
{
    if (this == &y)
    {
        return *this;
    }
    else
    {
        if (ndim!=y.ndim || nelem!=y.nelem)
        {
            this->~cgridI();
            ndim=y.ndim;
            nelem=y.nelem;
            alloc_cgridI();
        }
        for(int i=0;i<ndim;i++) nn[i]=y.nn[i];
        for(int i=0;i<nelem;i++) elem[i]=y.elem[i];

        return *this;
    }
}

#endif

