/*
 * realmpI.cpp
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "realmp.h"
#include "realmpI.h"

namespace torkam
{

realI val0I, val1I, val2I, val3I, val4I, val5I, val6I, val7I, val8I, val9I, val10I;
realI piI, pi2I, pihalfI;

realI::realI () 
{
	mpfi_init_set_d(x, 0.);
}

realI::realI (double a) 
{
	mpfi_init_set_d(x, a);
}

realI::realI (const real& a) 
{
	mpfi_init_set_fr(x, a.x);
}

realI::realI (int a) 
{
	mpfi_init_set_si(x, a);
}

realI::realI (double a, double b) 
{
  mpfi_init(x);
	mpfi_interv_d(x, a, b);
}

realI::realI (const char *a) 
{
	mpfi_init_set_str(x, a, 10);
}

realI::~realI()
{
	mpfi_clear(x);
}

void realI::setfull(double a, double b)
{
	mpfi_interv_d(x, a, b);

	return ;
}

void realI::setfull(mpfr_t a, mpfr_t b)
{
	mpfi_interv_fr(x, a, b);

	return ;
}

int realI::position(double a)
{
	mpfr_t left, right;
	int flag = 0, retl, retr;

	mpfr_init(left);
	mpfr_init(right);

	mpfi_get_left(left, x);
	mpfi_get_right(right, x);

	retl = mpfr_cmp_d(left, a);
	retr = mpfr_cmp_d(right, a);
	
	if(retl > 0)
	{
		flag = -1;
	}
	if(retr < 0)
	{
		flag = 1;
	}

	mpfr_clear(left);
	mpfr_clear(right);

	return flag;
}

int realI::position(mpfr_t a)const
{
	mpfr_t left, right;
	int flag = 0, retl, retr;

	mpfr_init(left);
	mpfr_init(right);

	mpfi_get_left(left, x);
	mpfi_get_right(right, x);

	retl = mpfr_cmp(left, a);
	retr = mpfr_cmp(right, a);
	
	if(retl > 0)
	{
		flag = -1;
	}
	if(retr < 0)
	{
		flag = 1;
	}

	mpfr_clear(left);
	mpfr_clear(right);

	return flag;
}

//Returns 0 if a is not inside x, 1 otherwise
int realI::is_inside(double a)
{
	int flag;

	flag = mpfi_is_inside_d(a, x);

	return flag;
}

double realI::left(void )
{	
	mpfr_t left;
	double res;

	mpfr_init(left);

	mpfi_get_left(left, x);
	res = mpfr_get_d(left, GMP_RNDD);

	mpfr_clear(left);

	return res;
}

double realI::right(void )
{	
	mpfr_t right;
	double res;

	mpfr_init(right);

	mpfi_get_right(right, x);
	res = mpfr_get_d(right, GMP_RNDU);

	mpfr_clear(right);

	return res;
}

real realI::left_real(void )
{	
	real left;

	mpfi_get_left(left.x, x);

	return left;
}

real realI::right_real(void )
{	
	real right;

	mpfi_get_right(right.x, x);

	return right;
}

realI& realI::operator = (const realI& P)
{
	if(this != &P)
	{
		mpfi_set(x, P.x);
	}
	return *this;
}

realI& realI::operator = (const double& P)
{
	mpfi_set_d(x, P);
	return *this;
}

realI& realI::operator = (const mpfr_t& P)
{
	mpfi_set_fr(x, P);
	return *this;
}

realI& realI::operator = (const real& P)
{
	mpfi_set_fr(x, P.x);
	return *this;
}

realI& realI::operator += (const realI& P)
{
	mpfi_add(x, x, P.x);
	return *this;
}

realI& realI::operator -= (const realI& P)
{
	mpfi_sub(x, x, P.x);

	return *this;
}

realI operator- (const realI& P)
{
	realI res;
  realI zero;

  zero = realI("0.");

	mpfi_sub(res.x, zero.x, P.x);

	return res;
}


realI operator+ (const realI& P, const realI& Q)
{
	realI res;

	mpfi_add(res.x, P.x, Q.x);

	return res;
}

realI operator+ (const double& P, const realI& Q)
{
	realI res;

	mpfi_add_d(res.x, Q.x, P);

	return res;
}

realI operator+ (const realI& Q, const double& P)
{
	realI res;

	mpfi_add_d(res.x, Q.x, P);

	return res;
}

realI operator+ (const mpfr_t& P, const realI& Q)
{
	realI res;

	mpfi_add_fr(res.x, Q.x, P);

	return res;
}

realI operator+ (const realI& Q, const mpfr_t& P)
{
	realI res;

	mpfi_add_fr(res.x, Q.x, P);

	return res;
}

realI operator- (const realI& P, const realI& Q)
{
	realI res;

	mpfi_sub(res.x, P.x, Q.x);

	return res;
}

realI operator- (const realI& P, const double& Q)
{
	realI res;

	mpfi_sub_d(res.x, P.x, Q);

	return res;
}

realI operator- (const double& P, const realI& Q)
{
	realI res;

	mpfi_d_sub(res.x, P, Q.x);

	return res;
}

realI operator- (const realI& P, const mpfr_t& Q)
{
	realI res;

	mpfi_sub_fr(res.x, P.x, Q);

	return res;
}

realI operator- (const mpfr_t& P, const realI& Q)
{
	realI res;

	mpfi_fr_sub(res.x, P, Q.x);

	return res;
}

realI operator- (const realI& P, const real& Q)
{
	realI res;

	mpfi_sub_fr(res.x, P.x, Q.x);

	return res;
}

realI operator- (const real& P, const realI& Q)
{
	realI res;

	mpfi_fr_sub(res.x, P.x, Q.x);

	return res;
}

realI operator* (const realI& P, const realI& Q)
{
	realI res;

	mpfi_mul(res.x, P.x, Q.x);

	return res;
}

realI operator* (const realI& P, const double& Q)
{
	realI res;

	mpfi_mul_d(res.x, P.x, Q);

	return res;
}
realI operator* (const double& P, const realI& Q)
{
	realI res;

	mpfi_mul_d(res.x, Q.x, P);

	return res;
}

realI operator* (const realI& P, const int& Q)
{
	realI res;

	mpfi_mul_si(res.x, P.x, Q);

	return res;
}

realI operator* (const realI& P, const real& Q)
{
	realI res;

	mpfi_mul_fr(res.x, P.x, Q.x);

	return res;
}

realI operator* (const real& P, const realI& Q)
{
	realI res;

	mpfi_mul_fr(res.x, Q.x, P.x);

	return res;
}

realI operator* (const int& P, const realI& Q)
{
	realI res;

	mpfi_mul_si(res.x, Q.x, P);

	return res;
}

realI operator/ (const realI& P, const realI& Q)
{
	realI res;

	mpfi_div(res.x, P.x, Q.x);

	return res;
}

realI operator/ (const realI& P, const double& Q)
{
	realI res;

	mpfi_div_d(res.x, P.x, Q);

	return res;
}

realI operator/ (const realI& P, const real& Q)
{
	realI res;

	mpfi_div_fr(res.x, P.x, Q.x);

	return res;
}

realI operator/ (const double& P, const realI& Q)
{
	realI res;

	mpfi_d_div(res.x, P, Q.x);

	return res;
}

realI abs(const realI& P)
{
	realI res;

	mpfi_abs(res.x, P.x);

	return res;
}

/*  DOC int is_inside(const realI& a, const realI& b)
 *  DOC 
 *  DOC Input: realI a, realI b
 *  DOC Output: return 0 if a is contained in b, 1 otherwise
 *  DOC 
 */
int is_inside(const realI& a, const realI& b)
{
  if(mpfi_is_inside(a.x, b.x) != 0)
  {
    return 0;
  }
  return 1;
}

void realmpI_allocate_cache(int prec)
{
  mpfr_set_default_prec(prec);

  mpfi_set_prec(val0I.x, prec); val0I = real(0.0);
  mpfi_set_prec(val1I.x, prec); val1I = real(1.0);
  mpfi_set_prec(val2I.x, prec); val2I = real(2.0);
  mpfi_set_prec(val3I.x, prec); val3I = real(3.0);
  mpfi_set_prec(val4I.x, prec); val4I = real(4.0);
  mpfi_set_prec(val5I.x, prec); val5I = real(5.0);
  mpfi_set_prec(val6I.x, prec); val6I = real(6.0);
  mpfi_set_prec(val7I.x, prec); val7I = real(7.0);
  mpfi_set_prec(val8I.x, prec); val8I = real(8.0);
  mpfi_set_prec(val9I.x, prec); val9I = real(9.0);
  mpfi_set_prec(val10I.x, prec); val10I = real(10.0);

  mpfi_set_prec(piI.x, prec); piI = const_piI();
  mpfi_set_prec(pi2I.x, prec); pi2I = piI*val2I;
  mpfi_set_prec(pihalfI.x, prec); pihalfI = piI/val2I;

  mpfr_free_cache (); 
}

realI midpointI(const realI& I)
{
  real c;
  realI res;

  mpfi_mid(c.x, I.x);

  res = c;

  return res;
}

realI const_piI(void)
{
  realI res;

  mpfi_const_pi(res.x);

  return res;
}


realI cos(const realI& P)
{
	realI res;

	mpfi_cos(res.x, P.x);

	return res;
}

realI sin(const realI& P)
{
	realI res;

	mpfi_sin(res.x, P.x);

	return res;
}

realI cosh(const realI& P)
{
	realI res;

	mpfi_cosh(res.x, P.x);

	return res;
}

realI sinh(const realI& P)
{
	realI res;

	mpfi_sinh(res.x, P.x);

	return res;
}

realI exp(const realI& P)
{
	realI res;

	mpfi_exp(res.x, P.x);

	return res;
}

realI log(const realI& P)
{
	realI res;

	mpfi_log(res.x, P.x);

	return res;
}

realI sqrt(const realI& P)
{
	realI res;

	mpfi_sqrt(res.x, P.x);

	return res;
}

realI sqr(const realI& P)
{
	realI res;

	mpfi_sqr(res.x, P.x);

	return res;
}

realI atan2(const realI& P, const realI& Q)
{
	realI res;

	mpfi_atan2(res.x, P.x, Q.x);

	return res;
}


realI pow(const realI& P, int N)
{
	realI res;
	int i;

	res = realI(1);
   if(N > 0)
   {
      for(i = 0; i < N; i++)
      {
         res = res*P;
      }
   }
   if(N < 0)
   {
      for(i = 0; i < -N; i++)
      {
         res = res/P;
      }
   }

	return res;
}

realI str_to_realI(char *s)
{
	realI res;

	mpfi_set_str(res.x, s, 10);

	return res;
}

bool check_invertibility(realI **A, int dim)
{
	bool res = true;
	int i, j, k, flag = 0, ipivotpos = 0, jpivotpos = 0;
	realI pivot, pivotline, pivotabs, *aux, aux0, aux1;
	mpfr_t left0, left1;

	mpfr_init(left0);
	mpfr_init(left1);

	aux = new realI[dim];

	for(i = 0; i < dim; i++)
	{
	/*	for(j = 0; j < dim; j++)
		{
			for(k = 0; k < dim; k++)
			{
				mpfi_out_str(stdout, 10, 8, A[j][k].x);
			}
			printf("\n");
		}
		printf("\n");*/
		flag = 0;
		for(j = i; j < dim; j++)
		{
			for(k = j; k < dim; k++)
			{
				mpfi_abs(aux0.x, A[j][k].x);
				if(mpfi_has_zero(aux0.x) > 0)
				{
					continue;
				}else
				{
					if(flag == 0)
					{
						ipivotpos = j;
						jpivotpos = k;
						pivotabs = aux0;
						flag = 1;
					}else
					{
						mpfi_mig(left0, aux0.x);
						mpfi_mig(left1, pivotabs.x);
						if(mpfr_cmp(left0, left1) > 0)
						{
							pivotabs = aux0;
							ipivotpos = j;
							jpivotpos = k;
						}
					}
				}
			}
		}
		if(flag == 0)
		{
			res = false;
			break;
		}
		if(ipivotpos != i)
		{
			for(j = 0; j < dim; j++)
			{
				aux[j] = A[ipivotpos][j];
				A[ipivotpos][j] = A[i][j];
				A[i][j] = aux[j];
			}
		}
		if(jpivotpos != i)
		{
			for(j = 0; j < dim; j++)
			{
				aux[j] = A[j][jpivotpos];
				A[j][jpivotpos] = A[j][i];
				A[j][i] = aux[j];
			}
		}
		pivot = A[i][i];
		for(j = i+1; j < dim; j++)
		{
			pivotline = A[j][i]/pivot;
			for(k = i; k < dim; k++)
			{
				A[j][k] = A[j][k]-A[i][k]*pivotline;
			}
		}
	}

	delete []aux;

	return res;
}

/*  DOC realI eval_pol(realI* coef, const realI& x, int N)
 *  DOC 
 *  DOC Input: array N with coef[0], ... coef[N-1]; x realI, N degree-1
 *  DOC Output: coef[0]+x*coef[1]+x^2*coef[2]+...+x^(N-1)*coef[N-1]
 *  DOC 
 */
realI eval_pol(realI* coef, const realI& x, int N)
{
  realI res;

  res = coef[N-1];

  for(int i = N-2; i > -1; i--)
  {
    res = res*x+coef[i];
  }

  return res;
}

/*  DOC realI unionI(const realI& a, const realI& b)
 *  DOC 
 *  DOC Input: realI a, realI b
 *  DOC Output: return an interval containing both a and b
 *  DOC 
 */

realI unionI(const realI& a, const realI& b)
{
  realI res;

  mpfi_union(res.x, a.x, b.x);

  return res;
}

}
