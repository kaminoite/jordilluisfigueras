/*
 * fft_mpfi.cc
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


#include<math.h>
#include"./Interval.hpp"

INTERVAL const_pi, const_2pi, const_2, const_half;
INTERVAL val0, val1, val2, val3, val4, val5, val16, val95, val100;
INTERVAL cR, cg, tau, Drho, RHOMIN, RHOMAX, Ddelta, DELTAMIN;
INTERVAL TOLBISx, TOLBISf, TOLSECx, TOLSECf, A2;
INTERVAL *WR, *WI;

void init_constants(int prec);
void four1(INTERVAL *data, unsigned long nn, int isign);
void init_coefficients(int prec, int n);
void obtain_coefficients(INTERVAL *dataP, unsigned long n);
void evaluation_series(INTERVAL *dataF, unsigned long n);
void init_coefficients(int prec, int n);
void evaluation_series_DFT(INTERVAL *dataF, unsigned long n);

void four1(INTERVAL *data, unsigned long nn, int isign)
{
	unsigned long n, mmax, m, j, istep, i, mystep;
	INTERVAL wr, wi;
	INTERVAL tempr, tempi, aux;

	n = nn << 1;
	j = 1;

	for(i = 1; i < n; i += 2)
	{
		if(j > i)
		{
			aux = data[j-1];
			data[j-1] = data[i-1];
			data[i-1] = aux;
			aux = data[j];
			data[j] = data[i];
			data[i] = aux;
		}
		m = n >>1;
		while(m >= 2 && j > m)
		{
			j -= m;
			m >>= 1;
		}
		j += m;
	}

	mmax = 2;
	mystep = 1;
	while(n > mmax)
	{
		istep = mmax << 1;
		for(m = 1; m < mmax; m += 2)
		{
			wr = WR[(m-1)*nn/4/mystep];
			if(isign == 1)
			{
				wi = WI[(m-1)*nn/4/mystep];
			}else
			{
				wi = INTERVAL(0)-WI[(m-1)*nn/4/mystep];
			}
			for(i = m; i <= n; i += istep)
			{
				j = i+mmax;
				tempr = wr*data[j-1]-wi*data[j];
				tempi = wr*data[j]+wi*data[j-1];
				data[j-1] = data[i-1]-tempr;
				data[j] = data[i]-tempi;
				data[i-1] = data[i-1]+tempr;
				data[i] = data[i]+tempi;
			}
		}
		mmax = istep;
		mystep = mystep*2;
	}
	
	return ;
}

void four1_original(INTERVAL *data, unsigned long nn, int isign)
{
	unsigned long n, mmax, m, j, istep, i;
	INTERVAL wtemp, wr, wpr, wpi, wi, theta;
	INTERVAL tempr, tempi, aux;

	n = nn << 1;
	j = 1;

	for(i = 1; i < n; i += 2)
	{
		if(j > i)
		{
			aux = data[j-1];
			data[j-1] = data[i-1];
			data[i-1] = aux;
			aux = data[j];
			data[j] = data[i];
			data[i] = aux;
		}
		m = n >>1;
		while(m >= 2 && j > m)
		{
			j -= m;
			m >>= 1;
		}
		j += m;
	}

	mmax = 2;
	while(n > mmax)
	{
		istep = mmax << 1;
		theta = isign*(const_2pi/mmax);
		wtemp = sin(theta*const_half);
		wpr = INTERVAL(0.)-const_2*wtemp*wtemp;
		wpi = sin(theta);
		wr = INTERVAL(1.);
		wi = INTERVAL(0.);
		for(m = 1; m < mmax; m += 2)
		{
			for(i = m; i <= n; i += istep)
			{
				j = i+mmax;
				tempr = wr*data[j-1]-wi*data[j];
				tempi = wr*data[j]+wi*data[j-1];
				data[j-1] = data[i-1]-tempr;
				data[j] = data[i]-tempi;
				data[i-1] = data[i-1]+tempr;
				data[i] = data[i]+tempi;
			}
			wtemp = wr;
			wr = wtemp*wpr-wi*wpi+wr;
			wi = wi*wpr+wtemp*wpi+wi;
		}
		mmax = istep;
	}
	
	return ;
}

void obtain_coefficients(INTERVAL *dataP, unsigned long n)
{
	unsigned int i;
	
	four1(dataP, n, -1);

	for(i = 0; i < n; i++)
	{
		dataP[2*i] = dataP[2*i]/INTERVAL(n);
		dataP[2*i+1] = dataP[2*i+1]/INTERVAL(n);
	}

	return ;
}

void evaluation_series(INTERVAL *dataF, unsigned long n)
{
	four1(dataF, n, 1);
	
	return ;
}

void init_constants(int prec)
{
	mpfi_set_prec(const_pi.x, prec);	
	mpfi_set_prec(const_2pi.x, prec);	
	mpfi_set_prec(const_2.x, prec);	
	mpfi_set_prec(const_half.x, prec);

	mpfi_const_pi(const_pi.x);
	
	const_2 = INTERVAL(2.);
	const_half = INTERVAL(1.)/const_2;

	const_2pi = const_pi+const_pi;

   mpfi_set_prec(val0.x, prec);
   mpfi_set_prec(val1.x, prec);
   mpfi_set_prec(val2.x, prec);
   mpfi_set_prec(val3.x, prec);
   mpfi_set_prec(val4.x, prec);
   mpfi_set_prec(val5.x, prec);
   mpfi_set_prec(val16.x, prec);
   mpfi_set_prec(val95.x, prec);
   mpfi_set_prec(val100.x, prec);
        
	mpfi_set_prec(cR.x, prec);
   mpfi_set_prec(cg.x, prec);
   mpfi_set_prec(tau.x, prec);
   mpfi_set_prec(Drho.x, prec);
   mpfi_set_prec(RHOMIN.x, prec);
   mpfi_set_prec(RHOMAX.x, prec);
   mpfi_set_prec(Ddelta.x, prec);
   mpfi_set_prec(DELTAMIN.x, prec);
   mpfi_set_prec(TOLBISx.x, prec);
   mpfi_set_prec(TOLBISf.x, prec);
   mpfi_set_prec(TOLSECx.x, prec);
   mpfi_set_prec(TOLSECf.x, prec);
   mpfi_set_prec(A2.x, prec);

   val0=0.0;
   val1=1.0;
   val2=2.0;
   val3=3.0;
   val4=4.0;
   val5=5.0;
   val16=16.0;
   val95=95.0;
   val100=100.0;
   cR=0.090378013797832003;
   cg=(val3-sqrt(val5))/val2;
   tau=1.0;
   Drho=100.0;
   RHOMIN=val1/Drho;
   RHOMAX=val1;
   Ddelta=100.0;
   DELTAMIN=val1/Ddelta;
   TOLBISx=1e-12;
   TOLBISf=1e-12;
   TOLSECx=1e-14;
   TOLSECf=1e-14;
   TOLSECx=1e-8;
   TOLSECf=1e-8;
   A2=val100;
   A2=1000000.;

   return ;
}

void init_coefficients(int prec, int n)
{
	int i;

	WR = new INTERVAL [n];
	WI = new INTERVAL [n];
	
	for(i = 0; i < n; i++)
	{
		mpfi_set_prec(WR[i].x, prec);	
		mpfi_set_prec(WI[i].x, prec);
		WR[i] = cos(const_2pi*INTERVAL(i)/INTERVAL(n));
		WI[i] = sin(const_2pi*INTERVAL(i)/INTERVAL(n));
	}

	return ;
}

void evaluation_series_DFT(INTERVAL *dataF, unsigned long n)
{
	int i, j;
	INTERVAL theta, resR, resI, *dataP;

	dataP = new INTERVAL [2*n];

	for(i = 0; i < (int)n; i++)
	{
		theta = INTERVAL(i, i+1.)/INTERVAL(n);
		resR = 0;
		resI = 0;
		for(j = n-1; j > -1; j--)
		{
			resR = resR+dataF[2*j]*cos(const_2pi*theta*j)-dataF[2*j+1]*sin(const_2pi*theta*j);
			resI = resI+dataF[2*j]*sin(const_2pi*theta*j)+dataF[2*j+1]*cos(const_2pi*theta*j);
		}
		dataP[2*i] = resR;
		dataP[2*i+1] = resI;
	}

	for(i = 0; i < (int)(2*n); i++)
	{
		dataF[i] = dataP[i];
	}
	delete [] dataP;

	return ;
}
