/*
 * realmp.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Joan Gimeno, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef __REALMP_H
#define __REALMP_H

#define REALMP_VERSION 2.0.0

#include <gmp.h>
#include <mpfr.h>
#include <iostream>

using namespace std;

namespace torkam 
{

class real
{
public:
  mpfr_t x;

  real(void);
  real(int a);
  real(unsigned int a);
  real(long a);
  real(unsigned long a);
  real(double a);
  real(const char *a);
  ~real(void);


  real operator+ (const real&) const;
  real operator+ (const double&) const;
  friend real operator+ (const double&, const real&);

  real operator- (void) const; // negate
  real operator- (const real&) const;
  friend real operator- (const double&, const real&);
  real operator- (const double&) const;

  real operator* (const real&) const;
  real operator* (const double&) const;
  real operator* (const int&) const;
  friend real operator* (const real&, const double&);

  real operator/ (const real&) const;
  friend real operator/ (const double&, const real&);
  real operator/ (const double&) const;
  real operator/ (const int&) const;
  real operator/ (const long int&) const;

  real& operator += (const real& y);
  real& operator *= (const real& y);
  real& operator /= (const real& y);

  real& operator = (const real& y);
  real& operator = (const double& y);
  real& operator = (const int& y);

  int operator> (const real& Q) const;
  int operator> (double Q) const;
  friend int operator> (double P, const real& Q);

  int operator< (const real& Q) const;
  int operator< (double Q) const;
  friend int operator< (double P, const real& Q);

  int operator>= (const real& Q) const;
  int operator>= (double Q) const;
  friend int operator>= (double P, const real& Q);

  int operator<= (const real& Q) const;
  int operator<= (double Q) const;
  friend int operator<= (double P, const real& Q);

  friend real sqr(const real& P);
};

// Global variables to be used everywhere
extern real val0, val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
extern real pi, pi2, pihalf;


int prec_digits_to_bits(int digits);
void realmp_allocate_cache(int prec);
void realmp_free_cache(void);
real const_pi(void);
real sin(const real& P);
real cos(const real& P);
real acos(const real& P);
real tan(const real& P);
real atan(const real& P);
real atan2(const real& Q, const real& P);
real sinh(const real& P);
real cosh(const real& P);
real exp(const real& P);
real log(const real& P);
real log10(const real& P);
real cubic(const real& P);
real sqrt(const real& P);
real abs(const real& P);
real pow(const real& P, int i);
real pow(const real& P, const real& x);
real max(const real& a, const real& b);
real max(const real& a, const real& b, const real& c);
real max(const real& a, const real& b, const real& c, const real& d);
real max(const real& a, const real& b, const real& c,
         const real& d, const real& e);
real ceil(const real& P);
real floor(const real& P);
real eval_pol(real* coef, const real& x, int N);
}
/*---------------------------------------------------------------------------*/

   
#endif

