/*
 * gridmp.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras, Alex Haro
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


// Alex:grid have real numbers, fourier have complex.

#ifndef GRIDMP_H
#define GRIDMP_H

#define GRIDMP_VERSION 2.0

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <math.h>
#include <cstring>

#include "realmp.h"
#include "complexmp.h"

using namespace std;

namespace torkam
{

class grid
{
public:
    
  int ndim;
  int nelem;
  int *nn;
  real *elem;

  grid();
  grid(const grid& y);
  grid(int d, int *n);
  ~grid();

  grid& operator = (const grid& g);

  void alloc_grid()
  {
    nn=new int[ndim];
    elem=new real[nelem];
  }
};

class cgrid
{
public:
    
  int ndim;
  int nelem;
  int *nn;
  complex *elem;

  cgrid();
  cgrid(const cgrid& y);
  cgrid(int d, int *n);
  ~cgrid();

  cgrid& operator = (const cgrid& f);

  void alloc_cgrid()
  {
    nn=new int[ndim];
    elem=new complex[nelem];
  }
};

typedef cgrid fourier;

// Real and imaginary parts of complex grids. Fill version
void realpart(const cgrid& g, grid& rg);
void imagpart(const cgrid& g, grid& ig);
void assign_realpart(const grid& rg, cgrid& g);
void assign_imagpart(const grid& ig, cgrid& g);

// FFT
//numerical recipes
void four1(real *data, int nn, int isign);
void fourn(real *data, int *nn, int ndim, int isign);
void parallel_perm_fourn(real *data, int *nn, int ndim, int isign, int nblocks, int precision);

// inplace version
void infft_F(cgrid& g); 
void infft_B(cgrid& f);

// fill objects
void fft_F(const grid& g, fourier& f);
void fft_B(const fourier& f, grid& g);

// generate objects
fourier fft_F(const grid& g);
grid fft_B(const fourier& f);

void trigo_to_series(int *nn, int *index, int *indexserie, int ndim);
void series_to_trigo(int *nn, int *indexserie, int *index, int ndim);
int position(int *nn, int *index, int ndim);
void indices(int pos, int *nn, int *index, int ndim);

void initialize_index_grid(int *index_grid, int ndim, int *nn);
void next_index_grid (int *index_grid, int ndim, int *nn);
void initialize_index_fourier (int *index_fourier, int ndim, int *nn);
void next_index_fourier (int *index_fourier, int ndim, int *nn);

// derivative with respect to theta_m
void inderivative(const fourier& f, int m); // inplace version
fourier derivative (const fourier& f, int m); // generate version 
void derivative(const fourier& f, int m, const fourier& df); //fill version
grid derivative(const grid& g, int m); // generate version

#define inRopcF inRopc
void inRopc(const fourier& f, real *omega); // inplace version
fourier Ropc(const fourier& f, real *omega); // generate version
void Ropc(const fourier& f, real *omega, const fourier& Ropcf); //fill version 
grid Ropc(const grid& g, real *omega); // genererate version
grid Ropc(const grid& g, real *omega, const grid& Ropcg);  //fill version

// grid shift (const grid& g, real *omega);
//grid shiftc (const grid& g, const real &rho);

void zerogrid(grid& g);
void constantgrid(grid& g, real& x);
void zerocgrid(cgrid& f);
void constantcgrid(cgrid& f, complex& z);
void constantcgrid(cgrid& f, real& x);

void clean (cgrid& f);
void clean_tail(cgrid& f);
void super_clean_tail (cgrid &f, int *flt);
cgrid get_tail(cgrid& f);
void clean_nyquist(cgrid& f); 
cgrid get_nyquist(cgrid& f);
real norm_nyquist(cgrid& f);
real tail(const cgrid& f, real *tf);

void clean(grid& g);
void clean_tail(grid& g);
void clean_nyquist(grid& g);
real norm_nyquist(grid& g);
real tail(const grid& g, real *tg);
  
//void obtain_real_analitic(grid& g);

void aver(const grid& g, real &avg);
real aver(const grid& g);
void aver(const cgrid& f, complex &avg);
complex aver(const cgrid& f);

real norm(const grid& g);
real norm(const cgrid& f);

/*
  real normsobo(const grid& g, const real& r);
  real normsup(const grid& g, const real& rho);
  real normexp(const grid& g, const real& rho);
*/

void print_grid(const grid& g);
void print_cgrid(const cgrid& f);

void fread_grid(const grid& g, FILE *fg);
void fwrite_grid(const grid& g, FILE *fg);

extern real tolcoho;
}
#endif
