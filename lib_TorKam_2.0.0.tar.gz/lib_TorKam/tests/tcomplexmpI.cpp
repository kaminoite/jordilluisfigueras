/*
 * tcomplexmpI.cc
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include<math.h>
#include"test.h"
#include<iostream>
#include"realmp.h"
#include"realmp_io.h"
#include"complexmp.h"
#include"realmpI.h"
#include"complexmpI.h"

using namespace std;
using namespace torkam;

real tol;

int test_is_inside(void)
{
  complexI a, b, c, d;

  a = unionI(realI(val0), realI(val1))+complexI(val0I, val1I)*unionI(realI(val0), realI(val1));
  b = unionI(realI(val1)/(realI(val4)), realI(val1)/(realI(val2)));
  c = unionI(realI(val0), realI(val1));
  d = unionI(realI(-val1)/(realI(val4)), realI(val1)/(realI(val2)));
  if(silent == FALSE)
    printf("Testing is_inside:\n");
  if(verbose == TRUE)
  {
//    mpfr_printf("\t a = %.20RDe , %.20RUe\n", a.left_real().x, a.right_real().x);
//    mpfr_printf("\t b = %.20RDe , %.20RUe\n", b.left_real().x, b.right_real().x);
    printf("Testing if a is contained in b: (YES)\n");
//    mpfr_printf("\t c = %.20RDe , %.20RUe\n", c.left_real().x, c.right_real().x);
//    mpfr_printf("\t d = %.20RDe , %.20RUe\n", d.left_real().x, d.right_real().x);
    printf("Testing if c is contained in d: (NO)\n");
  }
  printf("\t\t\t");
  if(is_inside(a, b) && is_inside(c, d))
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sin0(void)
{
  complexI a, c;
  a = val0;
  c = sin(a);

  if(silent == FALSE)
    printf("Testing |sin(0)-0| < tol:");
  if(abs(a-c).right_real() < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sinI(void)
{
  complex a, b, c;
  a = complex(val0, val1);
  c = sin(a);
  b = complex(val0, sinh(val1));

  if(silent == FALSE)
    printf("Testing |sin(I)-sinh(1)*I| < tol:\n");
  printf("\t\t\t");
  if(abs(c-b) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sinpi(void)
{
  complex a, c;
  a = pi;
  c = sin(a);

  if(silent == FALSE)
    printf("Testing |sin(pi)-0| < tol:");
  if(abs(val0-c) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sin2pi(void)
{
  complex a, c;
  a = pi2;
  c = sin(a);

  if(silent == FALSE)
    printf("Testing |sin(2pi)-0| < tol:");
  if(abs(val0-c) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sinpidiv2(void)
{
  complex a, c;
  a = pihalf;
  c = sin(a);

  if(silent == FALSE)
    printf("Testing |sin(pi/2)-1| < tol:");
  if(abs(val1-c) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_cos0(void)
{
  complex a, c;
  a = val0;
  c = cos(a);

  if(silent == FALSE)
    printf("Testing |cos(0)-1| < tol:");
  if(abs(val1-c) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_sqrt4(void)
{
  complex a, c;
  a = val4;
  c = val2;

  if(silent == FALSE)
    printf("Testing |sqrt(4)-2| < tol:");
  if(abs(sqrt(val4)-val2) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_Newton_sqrt2(int bits)
{
  complex a, res;
  a = complex(val1, val1/val10);
  res = sqrt(val2);

  if(silent == FALSE)
    printf("Testing Newton sqrt(2):\n");
  if(silent == FALSE)
    printf("\t Number of iterations = %d\n", (int)floor(log(bits)/log(2)));
  for(int i = 0; i < log(bits)/log(2); i++)
  {
    a = a-(sqr(a)-val2)/(val2*a);
  }
  if(verbose == TRUE)
  {
    mpfr_printf("\t Newton approximation = %.20Re+I%.20Re\n", a.re.x, a.im.x);
    mpfr_printf("\t sqrt(2) = %.20Re+I%.20Re\n", res.re.x, res.im.x);
    mpfr_printf("\t Difference = %.20Re\n", abs(a-res).x);
    mpfr_printf("\t tol = %.20Re\n", tol.x);
  }

  if(silent == FALSE)
    printf("\t\t\t");
  if(abs(sqrt(val2)-a) < tol)
  {
    return TRUE;
  }else
  {
    return FALSE;
  }
  return FALSE;
}

int test_eval_polynomials(void)
{
  complex res;
  complex *coef;
  complex x;
  int N;
  
  if(silent == FALSE)
    printf("Testing polynomial evaluation I+x+x^2:\n");
  if(silent == FALSE)
    printf("\t\t\t");

  N = 3;
  coef = new complex[N];
  for(int i = 0; i < N; i++)
  {
    coef[i] = val1;
  }
  coef[0] = complex(val0, val1);
  for(int j = 0; j < 10; j++)
  {
    x = real(j)/val10;
    res = eval_pol(coef, x, N);
    if(abs(res-(complex(val0, val1)+x+sqr(x))) > tol)
    {
      delete [] coef;
      return FALSE;
    }
  }
  delete [] coef;
  return TRUE;
}

int test_taylor_sin_cos(int bits)
{
  complex resc;
  complex ress;
  complex *coefc;
  complex *coefs;
  complex x;
  int N;
  
  if(silent == FALSE)
    printf("Testing Taylor sin(x) and cos(x):\n");

  N = bits;
  coefc = new complex[N];
  coefs = new complex[N];
  for(int i = 0; i < N; i++)
  {
    coefc[i] = val0;
    coefs[i] = val0;
  }
  coefc[0] = val1;
  coefs[0] = val0;
  for(int i = 1; i < N; i++)
  {
    coefc[i] = -coefs[i-1]/real(i);
    coefs[i] = coefc[i-1]/real(i);
  }
  for(int j = 0; j < 10; j++)
  {
    x = complex(val0, real(j)/val10/val2);
    resc = eval_pol(coefc, x, N);
    ress = eval_pol(coefs, x, N);
    if(verbose == TRUE)
    {
      printf("Testing cos(I%d/20) and sin(I%d/20)\n", j, j);
      mpfr_printf("\t taylor cos(I%d/20) = %.20Re+I%.20Re\n", j, resc.re.x, resc.im.x);
      mpfr_printf("\t abs(taylor cos(I%d/20)-cos(I%d/20)) = %.20Re\n", j, j, abs(cos(x)-resc).x);
      mpfr_printf("\t taylor sin(I%d/20) = %.20Re+I%.20Re\n", j, ress.re.x, ress.im.x);
      mpfr_printf("\t abs(taylor sin(I%d/20)-sin(I%d/20)) = %.20Re\n", j, j, abs(sin(x)-ress).x);
    }
    if(abs(resc-cos(x)) > tol || abs(ress-sin(x)) > tol)
    {
      printf("\t\t\t");
      delete [] coefc;
      delete [] coefs;
      return FALSE;
    }
  }
  if(silent == FALSE)
    printf("\t\t\t");
  delete [] coefc;
  delete [] coefs;
  return TRUE;

}

int main(int argc, char *argv[])
{
  ARG(argc, argv);

  START("Test tcomplexmp.x");

  int bits;
 
  for(bits = 30; bits < 1000; bits = bits+50)
  {
    realmp_allocate_cache(bits);
    
    tol = val1;

    for(int i = 0; i < bits/4*3; i++)
    {
      tol = tol/val2;
    }
    if(silent == FALSE)
    {
      printf("Number of bits = %d\n", bits);
      printf("tol = 2^(-3/4*bits)\n");
      mpfr_printf("tol = %.20Re\n", tol.x);
      printf("\n");
    }

    TEST(test_sin0());
    TEST(test_sinI());
    TEST(test_sinpi());
    TEST(test_sin2pi());
    TEST(test_sinpidiv2());
    TEST(test_cos0());
    TEST(test_sqrt4());
    TEST(test_Newton_sqrt2(bits));
    TEST(test_eval_polynomials());
    TEST(test_taylor_sin_cos(bits));
  }
  
  realmp_free_cache();

  END();

  return total-num_succ;
}


