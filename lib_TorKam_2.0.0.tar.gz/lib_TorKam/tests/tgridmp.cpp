/*
 * tgridmp.cc
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include<math.h>
#include"test.h"
#include<iostream>
#include"realmp.h"
#include"realmp_io.h"
#include"complexmp.h"
#include"gridmp.h"

using namespace std;
using namespace torkam;

real tol;

int test_creation(void)
{
  if(silent == FALSE)
    printf("Testing creation of grid:");
  
  grid K;
  int *nn;

  nn = new int[2];

  nn[0] = 16;
  nn[1] = 16;
 
  K = grid(2, nn);
 
  delete [] nn;

  return TRUE;
}

int test_fftF1d(void)
{
  if(silent == FALSE)
    printf("Testing fftF 1d:\t");
  
  grid K;
  int *nn, *index;
  real theta0;

  nn = new int[1];
  index = new int[1];

  nn[0] = 16;
 
  K = grid(1, nn);
 
  index = new int[1];
  initialize_index_grid(index, 1, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    K.elem[i] = val5+sin(theta0)-cos(theta0)-val2*cos(val2*theta0)+val3*sin(val4*theta0);
    next_index_grid(index, 1, nn);
  }
  fourier Kf;
  Kf = fourier(1, nn);
  
  Kf = fft_F(K);

  for(int i = 0; i < Kf.nelem; i++)
  {
    if(i == 0 || i == 1 || i == nn[0]-1 || i == 2 || i == nn[0]-2 || i == 4 || i == nn[0]-4)
    {
      continue;
    }
    if(abs(Kf.elem[i]) > tol)
    {
      delete [] nn;
      delete [] index;
      return FALSE;
    }
  }
  if(abs(Kf.elem[0]-val5) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  if(abs(Kf.elem[1].im+val1/val2) > tol || abs(Kf.elem[nn[0]-1].im-val1/val2) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  if(abs(Kf.elem[1].re+val1/val2) > tol || abs(Kf.elem[nn[0]-1].re+val1/val2) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  if(abs(Kf.elem[2].re+val1) > tol || abs(Kf.elem[nn[0]-2].re+val1) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  if(abs(Kf.elem[4].im+val3/val2) > tol || abs(Kf.elem[nn[0]-4].im-val3/val2) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  
 
  delete [] nn;
  delete [] index;

  return TRUE;
}

int test_fftF2d(void)
{
  if(silent == FALSE)
    printf("Testing fftF 2d:\t");
  
  grid K;
  int *nn, *index;
  real theta0, theta1;

  nn = new int[2];
  index = new int[2];

  nn[0] = 16;
  nn[1] = 16;
 
  K = grid(2, nn);
 
  index = new int[2];
  initialize_index_grid(index, 2, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    theta1 = pi2*index[1]/nn[1]; 
    K.elem[i] = val5+sin(theta0)+cos(theta1)-val2*cos(val2*theta0)+val3*cos(val3*theta1)+sin(theta0)*cos(theta1);
    next_index_grid(index, 2, nn);
  }
  fourier Kf;
  Kf = fourier(2, nn);
  
  Kf = fft_F(K);
 
  initialize_index_fourier(index, 2, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    if(index[0] == 0 && index[1] == 0)
    {
      if(abs(Kf.elem[i]-val5) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 1 && index[1] == 0)
    {
      if(abs(Kf.elem[i]-complex(val0, -val1/val2)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == -1 && index[1] == 0)
    {
      if(abs(Kf.elem[i]-complex(val0, val1/val2)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 0 && index[1] == 1)
    {
      if(abs(Kf.elem[i]-complex(val1/val2, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 0 && index[1] == -1)
    {
      if(abs(Kf.elem[i]-complex(val1/val2, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 1 && index[1] == 1)
    {
      if(abs(Kf.elem[i]-complex(val0, -val1/val4)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == -1 && index[1] == -1)
    {
      if(abs(Kf.elem[i]-complex(val0, val1/val4)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 1 && index[1] == -1)
    {
      if(abs(Kf.elem[i]-complex(val0, -val1/val4)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == -1 && index[1] == 1)
    {
      if(abs(Kf.elem[i]-complex(val0, val1/val4)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 2 && index[1] == 0)
    {
      if(abs(Kf.elem[i]-complex(-val1, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == -2 && index[1] == 0)
    {
      if(abs(Kf.elem[i]-complex(-val1, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 0 && index[1] == 3)
    {
      if(abs(Kf.elem[i]-complex(val3/val2, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(index[0] == 0 && index[1] == -3)
    {
      if(abs(Kf.elem[i]-complex(val3/val2, val0)) > tol)
      {
        delete [] nn;
        delete [] index;
        return FALSE;
      }
      next_index_fourier(index, 2, nn);
      continue;
    }
    if(abs(Kf.elem[i]) > tol)
    {
      delete [] nn;
      delete [] index;
      return FALSE;
    }
    next_index_fourier(index, 2, nn);
  }

  delete [] nn;
  delete [] index;

  return TRUE;
}

int test_fftFB1d(void)
{
  if(silent == FALSE)
    printf("Testing fftF and fftB 1d:");
  
  grid K, K2;
  int *nn, *index;
  real theta0;

  nn = new int[1];
  index = new int[1];

  nn[0] = 16;
 
  K = grid(1, nn);
 
  index = new int[1];
  initialize_index_grid(index, 1, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    K.elem[i] = val5+sin(theta0)-cos(theta0)-val2*cos(val2*theta0)+val3*sin(val4*theta0);
    next_index_grid(index, 1, nn);
  }
  fourier Kf;
  Kf = fourier(1, nn);
  
  Kf = fft_F(K);
  K2 = fft_B(Kf);

  for(int i = 0; i < K.nelem; i++)
  {
    if(abs(K2.elem[i]-K.elem[i]) > tol)
    {
      delete [] nn;
      delete [] index;
      return FALSE;
    }
  }

  delete [] nn;
  delete [] index;

  return TRUE;
}

int test_fftFB2d(void)
{
  if(silent == FALSE)
    printf("Testing fftF and fftB 2d:");
  
  grid K, K2;
  int *nn, *index;
  real theta0, theta1;

  nn = new int[2];
  index = new int[2];

  nn[0] = 32;
  nn[1] = 32;
 
  K = grid(2, nn);
 
  index = new int[2];
  initialize_index_grid(index, 2, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    theta1 = pi2*index[1]/nn[1]; 
    K.elem[i] = val3+sin(theta0)*cos(theta1)-cos(theta1)-val2*cos(val2*theta1)+val3*sin(val4*theta0);
    next_index_grid(index, 2, nn);
  }
  fourier Kf;
  Kf = fourier(2, nn);
  
  Kf = fft_F(K);
  K2 = fft_B(Kf);

  for(int i = 0; i < K.nelem; i++)
  {
    if(abs(K2.elem[i]-K.elem[i]) > tol)
    {
      delete [] nn;
      delete [] index;
      return FALSE;
    }
  }

  delete [] nn;
  delete [] index;

  return TRUE;
}


int test_derivative1d(void)
{
  if(silent == FALSE)
    printf("Testing derivative 1D of grid:");
  
  grid K, DK;
  real theta0, dk;
  int *nn;
  int *index;

  nn = new int[1];

  nn[0] = 32;
 
  K = grid(1, nn);
  index = new int[1];
  initialize_index_grid(index, 1, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    K.elem[i] = sin(theta0)+cos(val2*theta0)+val1-val3*sin(val5*theta0);
    next_index_grid(index, 1, nn);
  }
 
  fourier Kf;
  Kf = fourier(1, nn);
  
  DK = derivative(K, 0);
  Kf = fft_F(DK);
  initialize_index_grid(index, 1, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    dk = cos(theta0)-val2*sin(val2*theta0)-val3*val5*cos(val5*theta0);
    if(abs(DK.elem[i]-dk) > tol)
    {
      delete [] nn;
      delete [] index;
      return FALSE;
    }
    next_index_grid(index, 1, nn);
  }

  if(abs(Kf.elem[1]-val1/val2) > tol || abs(Kf.elem[nn[0]-1]-val1/val2) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  
  if(abs(Kf.elem[2].im-val1) > tol || abs(Kf.elem[nn[0]-2].im+val1) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }

  if(abs(Kf.elem[5]+val3*val5/val2) > tol || abs(Kf.elem[nn[0]-5]+val3*val5/val2) > tol)
  {
    delete [] nn;
    delete [] index;
    return FALSE;
  }
  delete [] nn;
  delete [] index;

  return TRUE;
}

int test_derivative2d(void)
{
  if(silent == FALSE)
    printf("Testing derivative of grid:");
  
  grid K, DK0, DK1;
  real theta0, theta1, dk0, dk1;
  int *nn;
  int *index;

  nn = new int[2];

  nn[0] = 16;
  nn[1] = 16;
 
  K = grid(2, nn);
  index = new int[2];
  initialize_index_grid(index, 2, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    theta1 = pi2*index[1]/nn[1];
    K.elem[i] = sin(theta0)-val2*cos(theta1)+val4*sin(val3*theta1)-val1/val2*cos(val5*theta0)+val2*sin(theta0)*cos(val2*theta1);
    next_index_grid(index, 2, nn);
  }
  fourier DKf0, DKf1;
  DKf0 = fourier(2, nn);
  DKf1 = fourier(2, nn);
  
  DK0 = derivative(K, 0);
  DK1 = derivative(K, 1);
  DKf0 = fft_F(DK0);
  DKf1 = fft_F(DK1);
  initialize_index_grid(index, 2, nn);
  for(int i = 0; i < K.nelem; i++)
  {
    theta0 = pi2*index[0]/nn[0]; 
    theta1 = pi2*index[1]/nn[1];
    dk0 = cos(theta0)+val5/val2*sin(val5*theta0)+val2*cos(theta0)*cos(val2*theta1);
    dk1 = val2*sin(theta1)+val4*val3*cos(val3*theta1)-val2*val2*sin(theta0)*sin(val2*theta1);
//    cout << "0 " << i << " " << dk0 << " " << DK0.elem[i] << endl;
//    cout << "1 " << i << " " << dk1 << " " << DK1.elem[i] << endl;
    if(abs(dk0-DK0.elem[i]) > tol)
    {
  //    cout << "err 0 " << i << " " << dk0 << " " << DK0.elem[i] << endl;
      delete [] nn;
      delete [] index;
      return FALSE;
    }
    if(abs(dk1-DK1.elem[i]) > tol)
    {
  //    cout << "err 1 " << i << " " << dk1 << " " << DK1.elem[i] << endl;
      delete [] nn;
      delete [] index;
      return FALSE;
    }

    next_index_grid(index, 2, nn);
  }

  delete [] nn;
  delete [] index;

  return TRUE;
}

int main(int argc, char *argv[])
{
  ARG(argc, argv);

  START("Test tgridmp.x");

  int bits;
 
  for(bits = 30; bits < 1000; bits = bits+50)
  {
    realmp_allocate_cache(bits);
    
    tol = val1;

    for(int i = 0; i < bits/4*3; i++)
    {
      tol = tol/val2;
    }
    if(silent == FALSE)
    {
      printf("Number of bits = %d\n", bits);
      printf("tol = 2^(-3/4*bits)\n");
      mpfr_printf("tol = %.20Re\n", tol.x);
      printf("\n");
    }

    TEST(test_creation());
    TEST(test_fftF1d());
    TEST(test_fftF2d());
    TEST(test_fftFB1d());
    TEST(test_fftFB2d());
    TEST(test_derivative1d());
    TEST(test_derivative2d());
  }

  realmp_free_cache();

  END();

  return total-num_succ;
}


