/*
 * test.h
 *
 * Copyright (c) 2024, Jordi-Lluís Figueras
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef __TEST
#define __TEST

#define TEST_VERSION 1.0.0

// The following color codes are from 
// https://stackoverflow.com/questions/1961209/making-some-text-in-printf-appear-in-green-and-red
#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

#define TRUE 1
#define FALSE 0

int num_succ = 0;
int total = 0;
int verbose = FALSE;
int silent = FALSE;

#include<stdio.h>
#include<string.h>

void ARG(int argc, char* argv[])
{
  if(argc < 2)
  {
    return ;
  }
  if(strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0)
  {
    printf("%s\n", argv[0]);
    printf("Arguments:\n");
    printf("\t -h: print this help\n");
    printf("\n");
    printf("\t --help: print this help\n");
    printf("\t --verbose: print more detailed output\n");
    printf("\t --silent: only print number of tests and how many passed\n");
    exit(0);
  }
  
  verbose = FALSE;
  if(strcmp(argv[1], "--verbose") == 0)
  {
    verbose = TRUE;
  }

  silent = FALSE;
  if(strcmp(argv[1], "--silent") == 0)
  {
    silent = TRUE;
  }

  return ;
}

void START(char name[100])
{
  printf(BLUE"--------------------------------\n");
  printf(BLUE"%s\n", name);
  printf(BLUE"--------------------------------\n");
  printf(RESET);
  printf("\n");
  total = 0;
}

void END(void)
{
  printf(BOLDBLUE"\nTotal tests = %d, Total passed = %d\n", total, num_succ);
  printf(RESET);
  if(total != num_succ)
  {
    printf(BOLDRED"WARNING: Not all tests passed\n");
    printf(RESET);
  }
}

void PSUCCESS(void)
{
  if(silent == FALSE)
  {
    printf(BOLDGREEN"---------SUCCESS!!!---------");
    printf(RESET);
  }

  return ;
}

void PFAIL(void)
{
  printf(BOLDRED"-----------FAIL!!!----------");
  printf(RESET);
  
  return ;
}

void TEST(int a)
{
  printf(RESET);
  printf("\t\t");
  if(a == TRUE)
  {
    PSUCCESS();
  }else
  {
    PFAIL();
  }
  total = total+1;
  num_succ = num_succ+a;
  if(silent == FALSE)
    printf("\n");
}

#endif

